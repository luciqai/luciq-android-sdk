#!/usr/bin/env python3
"""
Code Migration Module

Handles all Java/Kotlin code migrations including:
- Package name changes (com.instabug.* -> ai.luciq.*)
- Class name mappings (IBGNonFatalException -> LuciqNonFatalException)
- Method name mappings (isInstabugNotification -> isLuciqNotification)
- Import statements and fully qualified names

Author: Instabug SDK Team
Version: 1.0.0
"""

import os
import re
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set

logger = logging.getLogger(__name__)

class CodeMigrator:
    def __init__(self, project_path: Path, dry_run: bool = False, file_logger = None):
        self.project_path = project_path
        self.dry_run = dry_run
        self.file_logger = file_logger
        self.suppress_detailed_output = bool(file_logger and hasattr(file_logger, 'output_file_path') and file_logger.output_file_path and dry_run)
        self.stats = {
            'files_processed': 0,
            'files_modified': 0,
            'replacements_made': 0,
            'errors': 0
        }
        
        # File extensions to process (source code only, not scripts)
        self.code_extensions = {'.java', '.kt'}
        
        # Directories to skip
        self.skip_dirs = {
            '.git', '.gradle', 'build', '.idea', 
            'gradle', 'migration-backup', 'buildSrc'
        }
        
        # Class name mappings (exact matches)
        self.class_mappings = {
            'IBGNonFatalException': 'LuciqNonFatalException',
            'InstabugInvocationEvent': 'LuciqInvocationEvent',
            'InstabugFloatingButtonEdge': 'LuciqFloatingButtonEdge',
            'InstabugVideoRecordingButtonPosition': 'LuciqVideoRecordingButtonPosition',
            'IBGBugReportingType': 'LuciqBugReportingType',
            'InstabugApmOkHttpEventListener': 'LuciqApmOkHttpEventListener',
            'InstabugAPMGrpcInterceptor': 'LuciqAPMGrpcInterceptor',
            'InstabugAPMOkhttpInterceptor': 'LuciqAPMOkhttpInterceptor',
            'InstabugOkhttpInterceptor': 'LuciqOkhttpInterceptor',
            'InstabugColorTheme': 'LuciqColorTheme',
            'InstabugColorThemeLight': 'LuciqColorThemeLight',
            'InstabugColorThemeDark': 'LuciqColorThemeDark',
            'InstabugCustomTextPlaceHolder': 'LuciqCustomTextPlaceHolder',
            'IBGSessionLifecycleCallback': 'LuciqSessionLifecycleCallback',
            'IBGTheme': 'LuciqTheme',
            'Instabug': 'Luciq',
            'InstabugNetworkLog': 'LuciqNetworkLog',
            'InstabugLog': 'LuciqLog',
            'IBGFeatureFlag': 'LuciqFeatureFlag'
        }
        
        # Method name mappings (for regular method calls and extensions)
        self.method_mappings = {
            'isInstabugNotification': 'isLuciqNotification',
            'addInstabugApmInterceptor': 'addLuciqApmInterceptor',
            'ibgTrackingInfo': 'luciqTrackingInfo',
            'ibgPrivate': 'luciqPrivate',
            'setIBGLogsEnabled': 'setLuciqLogsEnabled',
            'setInstabugLogState': 'setLuciqLogState'
        }
        
        # Compose function mappings (for Compose functions and DSL functions)
        self.compose_mappings = {
            'IBGScreen': 'LuciqScreen',
            'AutoIBGScreen': 'AutoLuciqScreen',
            'ibgComposable_2_7': 'luciqComposable_2_7',
            'ibgComposable_2_8': 'luciqComposable_2_8',
            'ibgDialog': 'luciqDialog'
        }
        
        # Package mappings
        self.package_mappings = {
            'com.instabug.library': 'ai.luciq.library',
            'com.instabug.bug': 'ai.luciq.bug',
            'com.instabug.chat': 'ai.luciq.chat',
            'com.instabug.crash': 'ai.luciq.crash',
            'com.instabug.survey': 'ai.luciq.survey',
            'com.instabug.apm': 'ai.luciq.apm',
            'com.instabug.featuresrequest': 'ai.luciq.featuresrequest',
            'com.instabug.plugin': 'ai.luciq.plugin',
            'com.instabug.instabug_base_test': 'ai.luciq.instabug_base_test',
            'com.instabug.compose': 'ai.luciq.compose'
        }

    def migrate_all_code_files(self) -> bool:
        """Migrate all Java/Kotlin files in the project"""
        if self.file_logger:
            self.file_logger.log_step_header("Starting code migration...")
        else:
            logger.info("Starting code migration...")
        
        success = True
        processed_files = []
        
        # Find all code files
        for root, dirs, files in os.walk(self.project_path):
            # Skip unnecessary directories
            dirs[:] = [d for d in dirs if d not in self.skip_dirs]
            
            root_path = Path(root)
            
            for file in files:
                file_path = root_path / file
                
                if file_path.suffix in self.code_extensions:
                    processed_files.append(file_path)
        
        if self.file_logger:
            self.file_logger.log_step_header(f"Found {len(processed_files)} code files to process")
        else:
            logger.info(f"Found {len(processed_files)} code files to process")
        
        # Process each file
        for file_path in processed_files:
            if not self._migrate_code_file(file_path):
                success = False
        
        return success

    def _migrate_code_file(self, file_path: Path) -> bool:
        """Migrate a single Java/Kotlin file"""
        try:
            self.stats['files_processed'] += 1
            
            # Skip dry-run output files
            if self._is_dry_run_output_file(file_path):
                logger.info(f"Skipping {file_path.name} - detected as dry-run output file")
                return True
            
            # Read file content
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            except UnicodeDecodeError:
                try:
                    with open(file_path, 'r', encoding='latin-1') as f:
                        content = f.read()
                except:
                    logger.warning(f"Skipping binary file: {file_path}")
                    return True
            
            # Check if file contains any Instabug references
            if not self._contains_instabug_references(content):
                return True
            
            original_content = content
            modified_content = content
            replacements = 0
            
            # Step 1: Migrate package declarations
            modified_content, pkg_replacements = self._migrate_package_declarations(modified_content)
            replacements += pkg_replacements
            
            # Step 2: Migrate import statements
            modified_content, import_replacements = self._migrate_import_statements(modified_content)
            replacements += import_replacements
            
            # Step 3: Migrate class names
            modified_content, class_replacements = self._migrate_class_names(modified_content)
            replacements += class_replacements
            
            # Step 4: Migrate method names
            modified_content, method_replacements = self._migrate_method_names(modified_content)
            replacements += method_replacements
            
            # Step 5: Migrate Compose functions
            modified_content, compose_replacements = self._migrate_compose_functions(modified_content)
            replacements += compose_replacements
            
            # Step 6: Migrate fully qualified names
            modified_content, fqn_replacements = self._migrate_fully_qualified_names(modified_content)
            replacements += fqn_replacements
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {file_path} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {file_path} ({replacements} replacements)")
                    self._show_code_changes(file_path, original_content, modified_content)
                else:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {file_path} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating code file {file_path}: {e}")
            self.stats['errors'] += 1
            return False

    def _contains_instabug_references(self, content: str) -> bool:
        """Check if content contains any Instabug references"""
        instabug_indicators = [
            'com.instabug',
            'Instabug',
            'instabug',
            'IBG'
        ]
        
        return any(indicator in content for indicator in instabug_indicators)

    def _migrate_package_declarations(self, content: str) -> Tuple[str, int]:
        """Migrate package declarations"""
        modified_content = content
        replacements = 0
        
        # Pattern for package declarations
        pattern = r'\bpackage\s+(com\.instabug(?:\.[\w.]*)?)'
        
        def package_replacer(match):
            old_package = match.group(1)
            # Find the most specific mapping
            new_package = old_package
            for old_prefix, new_prefix in self.package_mappings.items():
                if old_package.startswith(old_prefix):
                    new_package = old_package.replace(old_prefix, new_prefix, 1)
                    break
            return f'package {new_package}'
        
        new_content, count = re.subn(pattern, package_replacer, modified_content)
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _migrate_import_statements(self, content: str) -> Tuple[str, int]:
        """Migrate import statements including package names and class names"""
        modified_content = content
        replacements = 0
        
        # Step 1: Migrate package names in imports
        pattern = r'\bimport\s+(com\.instabug(?:\.[\w.*]*)?)'
        
        def import_replacer(match):
            old_import = match.group(1)
            # Find the most specific mapping
            new_import = old_import
            for old_prefix, new_prefix in self.package_mappings.items():
                if old_import.startswith(old_prefix):
                    new_import = old_import.replace(old_prefix, new_prefix, 1)
                    break
            return f'import {new_import}'
        
        new_content, count = re.subn(pattern, import_replacer, modified_content)
        modified_content = new_content
        replacements += count
        
        # Step 2: Migrate class names in import statements (after package migration)
        # Pattern to match import statements with class names
        import_class_pattern = r'\bimport\s+(ai\.luciq\.[\w.]*\.)([A-Za-z_][A-Za-z0-9_]*)'
        
        def import_class_replacer(match):
            package_part = match.group(1)  # e.g., "ai.luciq.compose."
            class_name = match.group(2)    # e.g., "IBGScreen"
            
            # Check class mappings first
            if class_name in self.class_mappings:
                new_class_name = self.class_mappings[class_name]
                return f'import {package_part}{new_class_name}'
            
            # Check compose mappings
            elif class_name in self.compose_mappings:
                new_class_name = self.compose_mappings[class_name]
                return f'import {package_part}{new_class_name}'
            
            # Check method mappings (for extension functions that can be imported)
            elif class_name in self.method_mappings:
                new_class_name = self.method_mappings[class_name]
                return f'import {package_part}{new_class_name}'
            
            # No mapping found, return as-is
            return match.group(0)
        
        new_content, class_count = re.subn(import_class_pattern, import_class_replacer, modified_content)
        modified_content = new_content
        replacements += class_count
        
        return modified_content, replacements

    def _migrate_class_names(self, content: str) -> Tuple[str, int]:
        """Migrate class names using exact mappings"""
        modified_content = content
        replacements = 0
        
        for old_class, new_class in self.class_mappings.items():
            # Use word boundaries to ensure exact matches
            pattern = rf'\b{re.escape(old_class)}\b'
            new_content, count = re.subn(pattern, new_class, modified_content)
            modified_content = new_content
            replacements += count
        
        return modified_content, replacements

    def _migrate_method_names(self, content: str) -> Tuple[str, int]:
        """Migrate method names"""
        modified_content = content
        replacements = 0
        
        for old_method, new_method in self.method_mappings.items():
            # Pattern for method calls and declarations
            patterns = [
                # Method calls: object.method() or Class.method()
                (rf'(\w+\.){re.escape(old_method)}(\s*\()', rf'\g<1>{new_method}\g<2>'),
                # Method declarations: fun method() or public method()
                (rf'(\b(?:fun|public|private|protected|internal)\s+){re.escape(old_method)}(\s*\()', rf'\g<1>{new_method}\g<2>'),
                # Extension functions: fun Type.method()
                (rf'(\bfun\s+\w+\.){re.escape(old_method)}(\s*\()', rf'\g<1>{new_method}\g<2>'),
                # Chained method calls: .method() (for extension functions)
                (rf'(\.){re.escape(old_method)}(\s*\()', rf'\g<1>{new_method}\g<2>'),
                # Standalone function calls: method() (at word boundaries, no capturing group for \b)
                (rf'\b{re.escape(old_method)}(\s*\()', rf'{new_method}\g<1>')
            ]
            
            for pattern, replacement in patterns:
                new_content, count = re.subn(
                    pattern, 
                    replacement, 
                    modified_content
                )
                modified_content = new_content
                replacements += count
        
        return modified_content, replacements

    def _migrate_compose_functions(self, content: str) -> Tuple[str, int]:
        """Migrate Compose function names and DSL functions"""
        modified_content = content
        replacements = 0
        
        for old_function, new_function in self.compose_mappings.items():
            # Patterns for Compose function calls and DSL functions
            patterns = [
                # Compose function calls: Function() (at word boundaries, no capturing group for \b)
                (rf'\b{re.escape(old_function)}(\s*\()', rf'{new_function}\g<1>'),
                # DSL function calls within blocks: function("route") { }
                (rf'(\s+){re.escape(old_function)}(\s*\()', rf'\g<1>{new_function}\g<2>'),
                # Function calls at start of line (indented DSL)
                (rf'^(\s*){re.escape(old_function)}(\s*\()', rf'\g<1>{new_function}\g<2>')
            ]
            
            for pattern, replacement in patterns:
                new_content, count = re.subn(
                    pattern, 
                    replacement, 
                    modified_content,
                    flags=re.MULTILINE
                )
                modified_content = new_content
                replacements += count
        
        return modified_content, replacements

    def _migrate_fully_qualified_names(self, content: str) -> Tuple[str, int]:
        """Migrate fully qualified class names in code"""
        modified_content = content
        replacements = 0
        
        # Pattern for fully qualified names
        pattern = r'\bcom\.instabug(\.[\w.]*)?'
        
        def fqn_replacer(match):
            old_fqn = match.group(0)
            # Find the most specific mapping
            new_fqn = old_fqn
            for old_prefix, new_prefix in self.package_mappings.items():
                if old_fqn.startswith(old_prefix):
                    new_fqn = old_fqn.replace(old_prefix, new_prefix, 1)
                    break
            return new_fqn
        
        new_content, count = re.subn(pattern, fqn_replacer, modified_content)
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _show_code_changes(self, file_path: Path, original: str, modified: str):
        """Show code changes in dry-run mode"""
        original_lines = original.splitlines()
        modified_lines = modified.splitlines()
        
        for i, (orig_line, mod_line) in enumerate(zip(original_lines, modified_lines)):
            if orig_line != mod_line:
                if self.file_logger:
                    # Log to file and suppress console output when output file is specified
                    self.file_logger.log(f"  Line {i+1}: {orig_line.strip()}", to_console=not self.suppress_detailed_output)
                    self.file_logger.log(f"       →  {mod_line.strip()}", to_console=not self.suppress_detailed_output)
                else:
                    # Normal console output when no output file
                    logger.info(f"  Line {i+1}: {orig_line.strip()}")
                    logger.info(f"       →  {mod_line.strip()}")

    def _is_dry_run_output_file(self, file_path: Path) -> bool:
        """Check if a file is a dry-run output file by examining its header"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                first_line = f.readline().strip()
                return first_line.startswith("# Instabug to Luciq Migration Dry Run Output")
        except (UnicodeDecodeError, IOError):
            return False

    def get_stats(self) -> Dict[str, int]:
        """Get migration statistics"""
        return self.stats.copy()

    def get_class_mappings(self) -> Dict[str, str]:
        """Get class name mappings for reference"""
        return self.class_mappings.copy()

    def get_method_mappings(self) -> Dict[str, str]:
        """Get method name mappings for reference"""
        return self.method_mappings.copy()

    def get_package_mappings(self) -> Dict[str, str]:
        """Get package mappings for reference"""
        return self.package_mappings.copy()
