#!/usr/bin/env python3
"""
Others Migration Module

Handles migration of:
- AndroidManifest.xml files
- Resource files (instabug_config.json -> luciq_config.json)
- ProGuard rules
- Other configuration files

Author: Instabug SDK Team
Version: 1.0.0
"""

import os
import re
import json
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set

logger = logging.getLogger(__name__)

class OthersMigrator:
    def __init__(self, project_path: Path, dry_run: bool = False, file_logger = None):
        self.project_path = project_path
        self.dry_run = dry_run
        self.file_logger = file_logger
        self.suppress_detailed_output = bool(file_logger and hasattr(file_logger, 'output_file_path') and file_logger.output_file_path and dry_run)
        self.stats = {
            'files_processed': 0,
            'files_modified': 0,
            'replacements_made': 0,
            'errors': 0
        }
        
        # File extensions and patterns to process
        self.xml_extensions = {'.xml'}
        self.proguard_extensions = {'.pro', '.txt'}
        self.json_extensions = {'.json'}
        
        # Directories to skip
        self.skip_dirs = {
            '.git', '.gradle', 'build', '.idea', 
            'gradle', 'migration-backup'
        }
        
        # Manifest metadata mappings
        self.metadata_mappings = {
            'com.instabug.APP_TOKEN': 'ai.luciq.APP_TOKEN'
        }
        
        # Component mappings (Activities, ContentProviders, Services, etc.)
        # These mappings work on the ALREADY package-migrated names (ai.luciq.*)
        self.component_mappings = {
            # ContentProviders
            'ai.luciq.library.internal.contentprovider.InstabugContentProvider': 
                'ai.luciq.library.internal.contentprovider.LuciqContentProvider',
            
            # Activities
            'ai.luciq.bug.invocation.invocationdialog.InstabugDialogActivity':
                'ai.luciq.bug.invocation.invocationdialog.LuciqDialogActivity',
            'ai.luciq.bug.view.InstabugThanksActivity':
                'ai.luciq.bug.view.LuciqThanksActivity',
                
            # Other components - package changes only (no class name changes needed)
            # These will be handled by the general package migration
        }
        
        # Resource file mappings
        self.resource_file_mappings = {
            'instabug_config.json': 'luciq_config.json'
        }
        
        # JSON content mappings
        self.json_key_mappings = {
            'instabug_domain': 'luciq_domain'
        }
    
    def _filter_files_by_skip_dirs(self, files: List[Path]) -> List[Path]:
        """Filter out files that are in skip directories"""
        filtered_files = []
        for file_path in files:
            # Check if any parent directory is in skip_dirs
            skip_file = False
            for parent in file_path.parents:
                if parent.name in self.skip_dirs:
                    skip_file = True
                    break
            if not skip_file:
                filtered_files.append(file_path)
        return filtered_files
    
    def migrate_all_other_files(self) -> bool:
        """Migrate all other files (manifest, resources, proguard, etc.)"""
        if self.file_logger:
            self.file_logger.log_step_header("Starting other files migration...")
        else:
            logger.info("Starting other files migration...")
        
        success = True
        
        # Step 1: Migrate AndroidManifest.xml files
        if not self._migrate_manifest_files():
            success = False
            
        # Step 2: Migrate resource files
        if not self._migrate_resource_files():
            success = False
            
        # Step 3: Migrate ProGuard rules
        if not self._migrate_proguard_files():
            success = False
            
        # Step 4: Migrate other XML files
        if not self._migrate_other_xml_files():
            success = False
            
        return success

    def _migrate_manifest_files(self) -> bool:
        """Migrate AndroidManifest.xml files"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating AndroidManifest.xml files...")
        else:
            logger.info("Migrating AndroidManifest.xml files...")
        
        manifest_files = list(self.project_path.rglob("AndroidManifest.xml"))
        manifest_files = self._filter_files_by_skip_dirs(manifest_files)
        
        success = True
        for manifest_file in manifest_files:
            if not self._migrate_manifest_file(manifest_file):
                success = False
                
        return success

    def _migrate_manifest_file(self, manifest_file: Path) -> bool:
        """Migrate a single AndroidManifest.xml file"""
        try:
            self.stats['files_processed'] += 1
            
            # Skip dry-run output files
            if self._is_dry_run_output_file(manifest_file):
                logger.info(f"Skipping {manifest_file.name} - detected as dry-run output file")
                return True
            
            with open(manifest_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'com.instabug' not in content:
                return True
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Migrate package references
            modified_content, pkg_replacements = self._migrate_manifest_packages(modified_content)
            replacements += pkg_replacements
            
            # Migrate metadata
            modified_content, meta_replacements = self._migrate_manifest_metadata(modified_content)
            replacements += meta_replacements
            
            # Migrate Components (Activities, ContentProviders, Services, etc.)
            modified_content, component_replacements = self._migrate_components(modified_content)
            replacements += component_replacements
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {manifest_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {manifest_file} ({replacements} replacements)")
                    self._show_xml_changes(manifest_file, original_content, modified_content)
                else:
                    with open(manifest_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {manifest_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating manifest file {manifest_file}: {e}")
            self.stats['errors'] += 1
            return False

    def _migrate_manifest_packages(self, content: str) -> Tuple[str, int]:
        """Migrate package references in manifest"""
        modified_content = content
        replacements = 0
        
        # Replace com.instabug package references
        pattern = r'\bcom\.instabug(\.[\w.]*)?'
        new_content, count = re.subn(
            pattern, 
            lambda m: m.group(0).replace('com.instabug', 'ai.luciq'), 
            modified_content
        )
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _migrate_manifest_metadata(self, content: str) -> Tuple[str, int]:
        """Migrate metadata entries in manifest"""
        modified_content = content
        replacements = 0
        
        for old_meta, new_meta in self.metadata_mappings.items():
            # Pattern for metadata name attribute
            pattern = rf'android:name\s*=\s*["\']({re.escape(old_meta)})["\']'
            new_content, count = re.subn(
                pattern,
                rf'android:name="{new_meta}"',
                modified_content
            )
            modified_content = new_content
            replacements += count
        
        return modified_content, replacements

    def _migrate_components(self, content: str) -> Tuple[str, int]:
        """Migrate Component declarations (Activities, ContentProviders, Services, etc.)"""
        modified_content = content
        replacements = 0
        
        for old_component, new_component in self.component_mappings.items():
            # Pattern for component name attribute
            pattern = rf'android:name\s*=\s*["\']({re.escape(old_component)})["\']'
            new_content, count = re.subn(
                pattern,
                rf'android:name="{new_component}"',
                modified_content
            )
            modified_content = new_content
            replacements += count
        
        # Also migrate authorities attributes for ContentProviders
        # Pattern: android:authorities="...InstabugContentProvider" or android:authorities="${applicationId}...InstabugContentProvider"
        authorities_patterns = [
            (r'(android:authorities\s*=\s*["\'][^"\']*?)InstabugContentProvider([^"\']*["\'])', r'\1LuciqContentProvider\2'),
            (r'(android:authorities\s*=\s*["\'][^"\']*?)instabug([^"\']*["\'])', r'\1luciq\2'),
        ]
        
        for pattern, replacement in authorities_patterns:
            new_content, count = re.subn(pattern, replacement, modified_content, flags=re.IGNORECASE)
            modified_content = new_content
            replacements += count
        
        return modified_content, replacements

    def _migrate_resource_files(self) -> bool:
        """Migrate resource files"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating resource files...")
        else:
            logger.info("Migrating resource files...")
        
        success = True
        
        # Find res/raw directories
        raw_dirs = list(self.project_path.rglob("res/raw"))
        
        for raw_dir in raw_dirs:
            if not self._migrate_raw_directory(raw_dir):
                success = False
        
        return success

    def _migrate_raw_directory(self, raw_dir: Path) -> bool:
        """Migrate files in a res/raw directory"""
        try:
            for file_name, new_file_name in self.resource_file_mappings.items():
                old_file_path = raw_dir / file_name
                new_file_path = raw_dir / new_file_name
                
                if old_file_path.exists():
                    self.stats['files_processed'] += 1
                    
                    if self.dry_run:
                        logger.info(f"WOULD RENAME: {old_file_path} -> {new_file_path}")
                        
                        # Also migrate content
                        if old_file_path.suffix == '.json':
                            self._migrate_json_file_content_dry_run(old_file_path)
                    else:
                        # Migrate content first
                        if old_file_path.suffix == '.json':
                            self._migrate_json_file_content(old_file_path)
                        
                        # Rename file
                        old_file_path.rename(new_file_path)
                        logger.info(f"Renamed {old_file_path} -> {new_file_path}")
                    
                    self.stats['files_modified'] += 1
                    self.stats['replacements_made'] += 1
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating raw directory {raw_dir}: {e}")
            self.stats['errors'] += 1
            return False

    def _migrate_json_file_content(self, json_file: Path) -> bool:
        """Migrate content of a JSON file"""
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            try:
                # Parse JSON
                json_data = json.loads(content)
                
                # Migrate keys
                modified = False
                for old_key, new_key in self.json_key_mappings.items():
                    if old_key in json_data:
                        json_data[new_key] = json_data.pop(old_key)
                        modified = True
                
                if modified:
                    # Write back modified JSON
                    with open(json_file, 'w', encoding='utf-8') as f:
                        json.dump(json_data, f, indent=2)
                    
                    self.stats['replacements_made'] += len(self.json_key_mappings)
                
            except json.JSONDecodeError:
                # Fallback to regex-based replacement
                modified_content = content
                replacements = 0
                
                for old_key, new_key in self.json_key_mappings.items():
                    pattern = rf'["\']({re.escape(old_key)})["\']'
                    new_content, count = re.subn(
                        pattern,
                        rf'"{new_key}"',
                        modified_content
                    )
                    modified_content = new_content
                    replacements += count
                
                if replacements > 0:
                    with open(json_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    
                    self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating JSON content in {json_file}: {e}")
            return False

    def _migrate_json_file_content_dry_run(self, json_file: Path):
        """Show what would be changed in JSON file during dry run"""
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if self.file_logger:
                self.file_logger.log(f"WOULD MODIFY JSON CONTENT: {json_file}", to_console=not self.suppress_detailed_output)
            else:
                logger.info(f"WOULD MODIFY JSON CONTENT: {json_file}")
            
            try:
                json_data = json.loads(content)
                for old_key, new_key in self.json_key_mappings.items():
                    if old_key in json_data:
                        logger.info(f'  "{old_key}" -> "{new_key}"')
            except json.JSONDecodeError:
                logger.info("  JSON content would be migrated using regex fallback")
                
        except Exception as e:
            logger.warning(f"Could not preview JSON changes for {json_file}: {e}")

    def _migrate_proguard_files(self) -> bool:
        """Migrate ProGuard rule files"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating ProGuard files...")
        else:
            logger.info("Migrating ProGuard files...")
        
        proguard_files = []
        
        # Find ProGuard files
        for root, dirs, files in os.walk(self.project_path):
            dirs[:] = [d for d in dirs if d not in self.skip_dirs]
            
            root_path = Path(root)
            
            for file in files:
                file_path = root_path / file
                
                if (file_path.suffix in self.proguard_extensions or 
                    file_path.name in ['proguard-rules.pro', 'consumer-rules.pro']):
                    proguard_files.append(file_path)
        
        success = True
        for proguard_file in proguard_files:
            if not self._migrate_proguard_file(proguard_file):
                success = False
                
        return success

    def _migrate_proguard_file(self, proguard_file: Path) -> bool:
        """Migrate a single ProGuard file"""
        try:
            self.stats['files_processed'] += 1
            
            # Skip dry-run output files
            if self._is_dry_run_output_file(proguard_file):
                logger.info(f"Skipping {proguard_file.name} - detected as dry-run output file")
                return True
            
            with open(proguard_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'com.instabug' not in content:
                return True
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Replace package references
            pattern = r'\bcom\.instabug(\.[\w.*]*)?'
            new_content, count = re.subn(
                pattern,
                lambda m: m.group(0).replace('com.instabug', 'ai.luciq'),
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {proguard_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {proguard_file} ({replacements} replacements)")
                    self._show_proguard_changes(proguard_file, original_content, modified_content)
                else:
                    with open(proguard_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {proguard_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating ProGuard file {proguard_file}: {e}")
            self.stats['errors'] += 1
            return False

    def _migrate_other_xml_files(self) -> bool:
        """Migrate other XML files that might contain Instabug references"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating other XML files...")
        else:
            logger.info("Migrating other XML files...")
        
        xml_files = []
        
        # Find XML files (excluding AndroidManifest.xml which is handled separately)
        for root, dirs, files in os.walk(self.project_path):
            dirs[:] = [d for d in dirs if d not in self.skip_dirs]
            
            root_path = Path(root)
            
            for file in files:
                file_path = root_path / file
                
                if (file_path.suffix in self.xml_extensions and 
                    file_path.name != 'AndroidManifest.xml'):
                    xml_files.append(file_path)
        
        success = True
        for xml_file in xml_files:
            if not self._migrate_other_xml_file(xml_file):
                success = False
                
        return success

    def _migrate_other_xml_file(self, xml_file: Path) -> bool:
        """Migrate a single XML file"""
        try:
            self.stats['files_processed'] += 1
            
            # Skip dry-run output files
            if self._is_dry_run_output_file(xml_file):
                logger.info(f"Skipping {xml_file.name} - detected as dry-run output file")
                return True
            
            with open(xml_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'com.instabug' not in content:
                return True
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Replace package references
            pattern = r'\bcom\.instabug(\.[\w.]*)?'
            new_content, count = re.subn(
                pattern,
                lambda m: m.group(0).replace('com.instabug', 'ai.luciq'),
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {xml_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {xml_file} ({replacements} replacements)")
                    self._show_xml_changes(xml_file, original_content, modified_content)
                else:
                    with open(xml_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {xml_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating XML file {xml_file}: {e}")
            self.stats['errors'] += 1
            return False

    def _show_xml_changes(self, file_path: Path, original: str, modified: str):
        """Show XML file changes in dry-run mode"""
        self._show_file_changes(file_path, original, modified, "XML")

    def _show_proguard_changes(self, file_path: Path, original: str, modified: str):
        """Show ProGuard file changes in dry-run mode"""
        self._show_file_changes(file_path, original, modified, "ProGuard")

    def _show_file_changes(self, file_path: Path, original: str, modified: str, file_type: str):
        """Show file changes in dry-run mode"""
        original_lines = original.splitlines()
        modified_lines = modified.splitlines()
        
        for i, (orig_line, mod_line) in enumerate(zip(original_lines, modified_lines)):
            if orig_line != mod_line:
                if self.file_logger:
                    # Log to file and suppress console output when output file is specified
                    self.file_logger.log(f"  Line {i+1}: {orig_line.strip()}", to_console=not self.suppress_detailed_output)
                    self.file_logger.log(f"       →  {mod_line.strip()}", to_console=not self.suppress_detailed_output)
                else:
                    # Normal console output when no output file
                    logger.info(f"  Line {i+1}: {orig_line.strip()}")
                    logger.info(f"       →  {mod_line.strip()}")

    def _is_dry_run_output_file(self, file_path: Path) -> bool:
        """Check if a file is a dry-run output file by examining its header"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                first_line = f.readline().strip()
                return first_line.startswith("# Instabug to Luciq Migration Dry Run Output")
        except (UnicodeDecodeError, IOError):
            return False

    def get_stats(self) -> Dict[str, int]:
        """Get migration statistics"""
        return self.stats.copy()

    def get_metadata_mappings(self) -> Dict[str, str]:
        """Get metadata mappings for reference"""
        return self.metadata_mappings.copy()

    def get_component_mappings(self) -> Dict[str, str]:
        """Get Component mappings for reference"""
        return self.component_mappings.copy()

    def get_resource_file_mappings(self) -> Dict[str, str]:
        """Get resource file mappings for reference"""
        return self.resource_file_mappings.copy()
