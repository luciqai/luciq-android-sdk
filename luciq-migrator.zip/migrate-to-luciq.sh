#!/bin/bash

# Instabug to Luciq Migration Script Wrapper
# This script provides an easy way to run the Python migration script

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_SCRIPT="$SCRIPT_DIR/main-migrator.py"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_header() {
    echo -e "${BLUE}"
    echo "============================================================"
    echo "    Instabug to Luciq Comprehensive Migration Script"
    echo "============================================================"
    echo -e "${NC}"
    echo "This script performs a complete migration covering:"
    echo "• Gradle files (version catalogs, dependencies, plugins)"
    echo "• Java/Kotlin files (packages, imports, class names)"
    echo "• Other files (manifest, resources, ProGuard rules)"
    echo "• Automatic dependency installation when needed"
    echo "• Source-only mode for selective migration"
    echo ""
}

print_usage() {
    echo "Usage: ./luciq-migrator/migrate-to-luciq.sh [OPTIONS] [PROJECT_PATH]"
    echo ""
    echo "Options:"
    echo "  -h, --help                    Show this help message"
    echo "  -d, --dry-run                 Show what would be changed without making changes"
    echo "  -o, --output-file FILE        Write dry-run output to FILE (only with --dry-run)"
    echo "  -n, --no-backup               Skip creating backup (not recommended)"
    echo "  -s, --source-only             Migrate only Java/Kotlin files, Manifest & resources (skip Gradle)"
    echo ""
    echo "Examples:"
    echo "  ./luciq-migrator/migrate-to-luciq.sh                                      # Run on current directory (default)"
    echo "  ./luciq-migrator/migrate-to-luciq.sh /path/to/project                     # Run on specific project"
    echo "  ./luciq-migrator/migrate-to-luciq.sh --dry-run                            # Preview changes on current directory"
    echo "  ./luciq-migrator/migrate-to-luciq.sh --dry-run --output-file changes.txt # Preview and save to file"
    echo "  ./luciq-migrator/migrate-to-luciq.sh --source-only                        # Migrate only source code and resources"
    echo "  ./luciq-migrator/migrate-to-luciq.sh --source-only --dry-run              # Preview source-only changes"
}

install_dependencies() {
    echo -e "${BLUE}Installing missing dependencies...${NC}"
    echo ""
    
    # Check if pip3 is available
    local PIP_CMD
    if ! command -v pip3 &> /dev/null; then
        echo -e "${YELLOW}Warning: pip3 not found. Trying alternative installation methods...${NC}"
        
        # Try python3 -m pip
        if python3 -m pip --version &> /dev/null; then
            echo "Using python3 -m pip instead"
            PIP_CMD="python3 -m pip"
        else
            echo -e "${RED}Error: No pip installation method found.${NC}"
            echo "Please install pip3 first and try again."
            return 1
        fi
    else
        PIP_CMD="pip3"
    fi
    
    echo "Pip detected - OK"
    
    # TOML dependency removed - using regex-based parsing only
    echo -e "${GREEN}✓ Using regex-based TOML parsing (no external dependencies required)${NC}"
    return 0
}

check_requirements() {
    # Check if Python 3 is available
    if ! command -v python3 &> /dev/null; then
        echo -e "${RED}Error: Python 3 is required but not installed.${NC}"
        echo "Please install Python 3.6 or higher and try again."
        exit 1
    fi
    
    # Check Python version using Python itself for accurate comparison
    python3 -c "
import sys
if sys.version_info < (3, 6):
    print('Error: Python 3.6 or higher is required. Found: {}.{}'.format(sys.version_info.major, sys.version_info.minor))
    sys.exit(1)
else:
    print('Python {}.{} detected - OK'.format(sys.version_info.major, sys.version_info.minor))
" || exit 1
    
    # Check if all required Python scripts exist
    required_scripts=(
        "$PYTHON_SCRIPT"
        "$SCRIPT_DIR/gradle_migrator.py"
        "$SCRIPT_DIR/code_migrator.py"
        "$SCRIPT_DIR/others_migrator.py"
    )
    
    for script in "${required_scripts[@]}"; do
        if [[ ! -f "$script" ]]; then
            echo -e "${RED}Error: Required script not found: $script${NC}"
            echo "Please ensure all migration scripts are in the same directory."
            exit 1
        fi
    done
    
    # Using regex-based TOML parsing (no external dependencies required)
    echo -e "${GREEN}✓ Using regex-based TOML parsing - no external dependencies required${NC}"
}

confirm_action() {
    local project_path="$1"
    local dry_run="$2"
    local source_only="$3"
    local output_file="$4"
    
    if [[ "$dry_run" == "true" ]]; then
        if [[ "$source_only" == "true" ]]; then
            echo -e "${YELLOW}DRY RUN MODE (SOURCE-ONLY): No changes will be made${NC}"
        else
            echo -e "${YELLOW}DRY RUN MODE: No changes will be made${NC}"
        fi
        if [[ -n "$output_file" ]]; then
            echo -e "${BLUE}Output will be written to: $output_file${NC}"
        fi
        return 0
    fi
    
    if [[ "$source_only" == "true" ]]; then
        echo -e "${YELLOW}WARNING: This script will perform source-only migration!${NC}"
    else
        echo -e "${YELLOW}WARNING: This script will perform comprehensive migration!${NC}"
    fi
    echo "Project path: $project_path"
    echo ""
    echo "The script will:"
    if [[ "$source_only" != "true" ]]; then
        echo "  • Install missing dependencies if needed (TOML module)"
    fi
    echo "  • Create a backup of your project"
    if [[ "$source_only" != "true" ]]; then
        echo "  • Migrate Gradle files (version catalogs, dependencies, plugins)"
    fi
    echo "  • Migrate Java/Kotlin files (packages, imports, class names)"
    echo "  • Migrate other files (manifest, resources, ProGuard rules)"
    echo "  • Apply 20+ class name mappings (IBGNonFatalException → LuciqNonFatalException)"
    if [[ "$source_only" != "true" ]]; then
        echo "  • Handle complex plugin configurations (Instabug {} → instabug {})"
    fi
    echo ""
    read -p "Do you want to continue? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Operation cancelled."
        exit 0
    fi
}

main() {
    local project_path="."
    local dry_run="false"
    local no_backup="false"
    local source_only="false"
    local output_file=""
    local python_args=()
    
    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                print_usage
                exit 0
                ;;
            -d|--dry-run)
                dry_run="true"
                python_args+=("--dry-run")
                shift
                ;;
            -o|--output-file)
                if [[ -z "$2" ]]; then
                    echo -e "${RED}Error: --output-file requires a filename${NC}"
                    print_usage
                    exit 1
                fi
                output_file="$2"
                python_args+=("--output-file" "$2")
                shift 2
                ;;
            -n|--no-backup)
                no_backup="true"
                python_args+=("--no-backup")
                shift
                ;;
            -s|--source-only)
                source_only="true"
                python_args+=("--source-only")
                shift
                ;;
            -*)
                echo -e "${RED}Unknown option: $1${NC}"
                print_usage
                exit 1
                ;;
            *)
                project_path="$1"
                shift
                ;;
        esac
    done
    
    # Validate output-file option
    if [[ -n "$output_file" && "$dry_run" != "true" ]]; then
        echo -e "${RED}Error: --output-file can only be used with --dry-run${NC}"
        print_usage
        exit 1
    fi
    
    print_header
    
    # Check requirements (skip dependency check for source-only mode)
    if [[ "$source_only" != "true" ]]; then
        echo "Checking requirements..."
        check_requirements
        echo -e "${GREEN}✓ Requirements satisfied${NC}"
        echo ""
    else
        echo "Source-only mode: Skipping dependency checks..."
        # Still check Python and scripts
        if ! command -v python3 &> /dev/null; then
            echo -e "${RED}Error: Python 3 is required but not installed.${NC}"
            exit 1
        fi
        
        required_scripts=(
            "$PYTHON_SCRIPT"
            "$SCRIPT_DIR/code_migrator.py"
            "$SCRIPT_DIR/others_migrator.py"
        )
        
        for script in "${required_scripts[@]}"; do
            if [[ ! -f "$script" ]]; then
                echo -e "${RED}Error: Required script not found: $script${NC}"
                exit 1
            fi
        done
        
        echo -e "${GREEN}✓ Basic requirements satisfied${NC}"
        echo ""
    fi
    
    # Confirm action
    confirm_action "$project_path" "$dry_run" "$source_only" "$output_file"
    echo ""
    
    # Add project path to arguments
    python_args+=("$project_path")
    
    # Run the Python script
    echo "Running migration script..."
    echo "Command: python3 $PYTHON_SCRIPT ${python_args[*]}"
    echo ""
    
    if python3 "$PYTHON_SCRIPT" "${python_args[@]}"; then
        echo ""
        echo -e "${GREEN}✓ Migration completed successfully!${NC}"
        
        if [[ "$dry_run" == "true" ]]; then
            if [[ -n "$output_file" ]]; then
                echo ""
                echo -e "${BLUE}📄 Dry run output has been written to: $output_file${NC}"
                echo "Review the file to see all changes that would be made."
            fi
        else
            echo ""
            echo -e "${YELLOW}Next steps:${NC}"
            echo "1. Build your project: ./gradlew clean build"
            echo "2. Run your tests: ./gradlew test"
            echo "3. Test your app functionality thoroughly"
            echo "4. Verify no old references remain:"
            echo '   grep -r "com\.instabug" . --exclude-dir=migration-backup'
            echo ""
            echo "If you encounter issues, restore from the backup created in:"
            echo "  $(realpath "$project_path")/migration-backup/"
            echo ""
            echo -e "${GREEN}Migration completed! Your project now uses ai.luciq.* packages.${NC}"
            echo -e "${GREEN}All dependencies were automatically handled during the migration.${NC}"
        fi
    else
        echo ""
        echo -e "${RED}✗ Migration failed. Check the output above for details.${NC}"
        exit 1
    fi
}

# The version check now uses built-in bash arithmetic, no need for bc

main "$@"
