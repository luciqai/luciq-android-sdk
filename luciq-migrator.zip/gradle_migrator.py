#!/usr/bin/env python3
"""
Gradle Migration Module

Handles all Gradle-related migrations including:
- Version Catalogs (libs.versions.toml)
- Dependencies in build.gradle files
- Plugin declarations and integrations
- Configuration blocks (Instabug -> instabug)

Author: Instabug SDK Team
Version: 1.0.0
"""

import os
import re
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set

# Using regex-based TOML parsing only (no external dependencies)
TOML_AVAILABLE = False
toml = None

logger = logging.getLogger(__name__)

class GradleMigrator:
    def __init__(self, project_path: Path, dry_run: bool = False, file_logger = None):
        self.project_path = project_path
        self.dry_run = dry_run
        self.file_logger = file_logger
        self.suppress_detailed_output = bool(file_logger and hasattr(file_logger, 'output_file_path') and file_logger.output_file_path and dry_run)
        self.stats = {
            'files_processed': 0,
            'files_modified': 0,
            'replacements_made': 0,
            'errors': 0
        }
        
        # Directories to skip during migration
        self.skip_dirs = {
            '.git', '.gradle', 'build', '.idea', 
            'gradle', 'migration-backup'
        }
        
        # Version mappings
        self.luciq_version = "18.2.0"
        
        # Complete artifact name mappings from migration guide
        self.artifact_mappings = {
            'instabug': 'luciq',
            'instabug-apm': 'luciq-apm',
            'instabug-crash': 'luciq-crash',
            'instabug-bug': 'luciq-bug',
            'instabug-survey': 'luciq-survey',
            'instabug-features-request': 'luciq-features-request',
            'instabug-ndk-crash': 'luciq-ndk-crash',
            'instabug-compose': 'luciq-compose',
            'instabug-compose-apm': 'luciq-compose-apm',
            'instabug-apm-okhttp-interceptor': 'luciq-apm-okhttp-interceptor',
            'instabug-apm-grpc-interceptor': 'luciq-apm-grpc-interceptor',
            'instabug-core': 'luciq-core',
            'instabug-with-okhttp-interceptor': 'luciq-with-okhttp-interceptor',
            'instabug-plugin': 'luciq-plugin',
            'instabug-compiler-extension': 'luciq-compiler-extension',
            'instabug-test-report': 'luciq-test-report',
            'instabug-compose-core': 'luciq-compose-core'
        }
        
        # Configuration mappings
        self.config_mappings = {
            'Instabug': 'instabug',  # Legacy -> New
            'APM': 'apm',
            'debugEnabled': 'debugLogsEnabled'
        }
    
    def _filter_files_by_skip_dirs(self, files: List[Path]) -> List[Path]:
        """Filter out files that are in skip directories, with exceptions for important files"""
        filtered_files = []
        for file_path in files:
            # Check if any parent directory is in skip_dirs
            skip_file = False
            for parent in file_path.parents:
                if parent.name in self.skip_dirs:
                    # Special exception: Allow TOML files in gradle directory (version catalogs)
                    if parent.name == 'gradle' and file_path.suffix.lower() == '.toml':
                        continue  # Don't skip TOML files in gradle directory
                    skip_file = True
                    break
            if not skip_file:
                filtered_files.append(file_path)
        return filtered_files

    def migrate_all_gradle_files(self) -> bool:
        """Migrate all Gradle-related files in the project"""
        if self.file_logger:
            self.file_logger.log_step_header("Starting Gradle migration...")
        else:
            logger.info("Starting Gradle migration...")
        
        success = True
        
        # Step 1: Migrate Version Catalogs
        if not self._migrate_version_catalogs():
            success = False
            
        # Step 2: Migrate build.gradle files
        if not self._migrate_build_gradle_files():
            success = False
            
        # Step 3: Migrate plugin configurations
        if not self._migrate_plugin_configurations():
            success = False
            
        # Step 4: Migrate buildSrc files
        if not self._migrate_buildsrc_files():
            success = False
            
        return success

    def _migrate_version_catalogs(self) -> bool:
        """Migrate libs.versions.toml files"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating version catalogs...")
        else:
            logger.info("Migrating version catalogs...")
        
        # Find all TOML files
        toml_files = list(self.project_path.rglob("*.toml"))
        toml_files = self._filter_files_by_skip_dirs(toml_files)
        
        logger.info(f"Found {len(toml_files)} TOML files: {[f.name for f in toml_files]}")
        
        # Filter for version catalog files (more inclusive approach)
        version_catalog_files = []
        for f in toml_files:
            filename_lower = f.name.lower()
            # Check for common version catalog patterns
            if any(pattern in filename_lower for pattern in ['version', 'libs', 'catalog', 'dependencies']):
                version_catalog_files.append(f)
            # Also check content for version catalog indicators
            else:
                try:
                    with open(f, 'r', encoding='utf-8') as file:
                        content = file.read()
                        if any(indicator in content for indicator in ['[versions]', '[libraries]', '[plugins]', 'com.instabug']):
                            version_catalog_files.append(f)
                            logger.info(f"Added {f.name} based on content analysis")
                except Exception:
                    pass  # Skip files that can't be read
        
        logger.info(f"Processing {len(version_catalog_files)} version catalog files: {[f.name for f in version_catalog_files]}")
        
        success = True
        for toml_file in version_catalog_files:
            if not self._migrate_version_catalog_file(toml_file):
                success = False
                
        return success


    def _migrate_toml_with_regex(self, content: str) -> tuple[str, int]:
        """Fallback regex-based TOML migration when TOML parsing is not available"""
        modified_content = content
        replacements = 0
        
        # FIRST: Track version references that are actually used by Instabug libraries
        # This must be done BEFORE we replace the group/plugin IDs
        version_refs_used_by_instabug = set()
        
        # Find libraries that use com.instabug.library group (and its variations) and track their version refs
        library_pattern = r'([\w-]+)\s*=\s*\{[^}]*group\s*=\s*"com\.instabug\.library(?:-[^"]*)?[^}]*version\.ref\s*=\s*"([^"]+)"[^}]*\}'
        for match in re.finditer(library_pattern, content):
            version_ref = match.group(2)
            version_refs_used_by_instabug.add(version_ref)
        
        # Also find libraries that use module format with com.instabug.library (and its variations) and track their version refs
        module_pattern = r'([\w-]+)\s*=\s*\{[^}]*module\s*=\s*"com\.instabug\.library(?:-[^"]*)?:[^"]*"[^}]*version\.ref\s*=\s*"([^"]+)"[^}]*\}'
        for match in re.finditer(module_pattern, content):
            version_ref = match.group(2)
            version_refs_used_by_instabug.add(version_ref)
        
        # Also find plugins that use com.instabug.library (and its variations) id and track their version refs
        plugin_pattern = r'([\w-]+)\s*=\s*\{[^}]*id\s*=\s*"com\.instabug\.library(?:-[^"]*)?[^}]*version\.ref\s*=\s*"([^"]+)"[^}]*\}'
        for match in re.finditer(plugin_pattern, content):
            version_ref = match.group(2)
            version_refs_used_by_instabug.add(version_ref)
        
        # 1. Replace group references in libraries section (preserving variations)
        pattern = r'group\s*=\s*"com\.instabug\.library(-[^"]*)?'
        def replace_group_reference(match):
            variation = match.group(1) if match.group(1) else ""
            return f'group = "ai.luciq.library{variation}'
        new_content, count = re.subn(pattern, replace_group_reference, modified_content)
        modified_content = new_content
        replacements += count
        
        # 2. Replace plugin IDs (preserving variations)
        pattern = r'id\s*=\s*"com\.instabug\.library(-[^"]*)?'
        def replace_plugin_id(match):
            variation = match.group(1) if match.group(1) else ""
            return f'id = "ai.luciq.library{variation}'
        new_content, count = re.subn(pattern, replace_plugin_id, modified_content)
        modified_content = new_content
        replacements += count
        
        # 3. Replace module format dependencies (preserving variations like com.instabug.library-verizon)
        def replace_module_dependency(match):
            prefix = match.group(1)
            old_artifact = match.group(2)
            suffix = match.group(3)
            
            # Replace the group part (preserve variations like com.instabug.library-verizon)
            import re as inner_re
            def replace_group_in_module(group_match):
                variation = group_match.group(1) if group_match.group(1) else ""
                return f'ai.luciq.library{variation}:'
            
            new_artifact = inner_re.sub(r'com\.instabug\.library(-[^:]*)?:', replace_group_in_module, old_artifact)
            
            # Replace the artifact name if it matches our mappings
            for old_name, new_name in self.artifact_mappings.items():
                if new_artifact.endswith(':' + old_name):
                    new_artifact = new_artifact.replace(':' + old_name, ':' + new_name)
                    break
            
            return f'{prefix}"{new_artifact}"{suffix}'
        
        module_replacement_pattern = r'(module\s*=\s*)"(com\.instabug\.library(?:-[^:]*)?:[^"]+)"([^}]*)'
        new_content, count = re.subn(module_replacement_pattern, replace_module_dependency, modified_content)
        modified_content = new_content
        replacements += count
        
        # 4. Replace artifact names in libraries section (be more specific)
        for old_name, new_name in self.artifact_mappings.items():
            pattern = rf'name\s*=\s*"{re.escape(old_name)}"'
            new_content, count = re.subn(pattern, f'name = "{new_name}"', modified_content)
            modified_content = new_content
            replacements += count
        
        # 5. Update version references that are actually used by Instabug libraries
        # Since we've already identified these as Instabug-related through dependency tracking,
        # we should unconditionally update them to the Luciq version
        for version_ref in version_refs_used_by_instabug:
            pattern = rf'({re.escape(version_ref)})\s*=\s*"([^"]+)"'
            
            def replace_instabug_version_ref(match):
                key = match.group(1)
                old_version = match.group(2)
                # Unconditionally replace since this version ref is used by Instabug dependencies
                return f'{key} = "{self.luciq_version}"'
            
            new_content, count = re.subn(pattern, replace_instabug_version_ref, modified_content)
            modified_content = new_content
            replacements += count
        
        # 6. Handle hardcoded versions in Instabug library/plugin declarations
        # Find libraries with group format that have hardcoded versions
        hardcoded_library_pattern = r'([\w-]+\s*=\s*\{[^}]*group\s*=\s*"ai\.luciq\.library"[^}]*version\s*=\s*)"([^"]+)"([^}]*\})'
        
        def replace_hardcoded_library_version(match):
            prefix = match.group(1)
            old_version = match.group(2)
            suffix = match.group(3)
            # Replace hardcoded version with Luciq version
            return f'{prefix}"{self.luciq_version}"{suffix}'
        
        new_content, count = re.subn(hardcoded_library_pattern, replace_hardcoded_library_version, modified_content)
        modified_content = new_content
        replacements += count
        
        # Also handle hardcoded versions in module format
        hardcoded_module_pattern = r'([\w-]+\s*=\s*\{[^}]*module\s*=\s*"ai\.luciq\.library:[^"]*"[^}]*version\s*=\s*)"([^"]+)"([^}]*\})'
        
        def replace_hardcoded_module_version(match):
            prefix = match.group(1)
            old_version = match.group(2)
            suffix = match.group(3)
            # Replace hardcoded version with Luciq version
            return f'{prefix}"{self.luciq_version}"{suffix}'
        
        new_content, count = re.subn(hardcoded_module_pattern, replace_hardcoded_module_version, modified_content)
        modified_content = new_content
        replacements += count
        
        # Also handle plugins with hardcoded versions (though less common)
        hardcoded_plugin_pattern = r'([\w-]+\s*=\s*\{[^}]*id\s*=\s*"ai\.luciq\.library"[^}]*version\s*=\s*)"([^"]+)"([^}]*\})'
        
        def replace_hardcoded_plugin_version(match):
            prefix = match.group(1)
            old_version = match.group(2)
            suffix = match.group(3)
            # Replace hardcoded version with Luciq version
            return f'{prefix}"{self.luciq_version}"{suffix}'
        
        new_content, count = re.subn(hardcoded_plugin_pattern, replace_hardcoded_plugin_version, modified_content)
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _migrate_version_catalog_file(self, toml_file: Path) -> bool:
        """Migrate a single version catalog file"""
        try:
            self.stats['files_processed'] += 1
            
            # Skip dry-run output files
            if self._is_dry_run_output_file(toml_file):
                logger.info(f"Skipping {toml_file.name} - detected as dry-run output file")
                return True
            
            with open(toml_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'com.instabug' not in content:
                logger.info(f"Skipping {toml_file.name} - no Instabug references found")
                return True
            
            logger.info(f"Processing {toml_file.name} - Instabug references detected")
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Use regex-based approach for TOML migration (no external dependencies)
            modified_content, regex_replacements = self._migrate_toml_with_regex(content)
            replacements += regex_replacements
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {toml_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {toml_file} ({replacements} replacements)")
                    self._show_toml_changes(toml_file, original_content, modified_content)
                else:
                    with open(toml_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {toml_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating version catalog {toml_file}: {e}")
            self.stats['errors'] += 1
            return False


    def _migrate_build_gradle_files(self) -> bool:
        """Migrate all build.gradle and build.gradle.kts files"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating build.gradle files...")
        else:
            logger.info("Migrating build.gradle files...")
        
        gradle_files = list(self.project_path.rglob("build.gradle*"))
        gradle_files = self._filter_files_by_skip_dirs(gradle_files)
        
        success = True
        for gradle_file in gradle_files:
            if not self._migrate_build_gradle_file(gradle_file):
                success = False
                
        return success

    def _migrate_build_gradle_file(self, gradle_file: Path) -> bool:
        """Migrate a single build.gradle file"""
        try:
            self.stats['files_processed'] += 1
            
            # Skip dry-run output files
            if self._is_dry_run_output_file(gradle_file):
                logger.info(f"Skipping {gradle_file.name} - detected as dry-run output file")
                return True
            
            with open(gradle_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'com.instabug' not in content and 'instabug' not in content:
                return True
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Migrate dependencies
            modified_content, deps_replacements = self._migrate_dependencies(modified_content)
            replacements += deps_replacements
            
            # Migrate plugin declarations
            modified_content, plugin_replacements = self._migrate_plugin_declarations(modified_content)
            replacements += plugin_replacements
            
            # Migrate buildScript dependencies
            modified_content, buildscript_replacements = self._migrate_buildscript_dependencies(modified_content)
            replacements += buildscript_replacements
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {gradle_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {gradle_file} ({replacements} replacements)")
                    self._show_gradle_changes(gradle_file, original_content, modified_content)
                else:
                    with open(gradle_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {gradle_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating build.gradle file {gradle_file}: {e}")
            self.stats['errors'] += 1
            return False

    def _migrate_dependencies(self, content: str) -> Tuple[str, int]:
        """Migrate dependency declarations with smart variable tracking"""
        modified_content = content
        replacements = 0
        
        # FIRST: Track version variables that are actually used by Instabug dependencies
        # This must be done BEFORE we replace the group/artifact names
        variables_used_by_instabug = set()
        
        # Find dependencies that use com.instabug.library (and its variations) and track their version variables
        for old_name, new_name in self.artifact_mappings.items():
            # Track variables in "com.instabug.library:artifact:$variable" and "com.instabug.library:artifact:${variable}" formats (including variations)
            variable_usage_pattern = rf'["\']com\.instabug\.library(?:-[^:]*)?:{re.escape(old_name)}:\$\{{?([a-zA-Z_][a-zA-Z0-9_]*)\}}?["\']'
            for match in re.finditer(variable_usage_pattern, content):
                var_name = match.group(1)
                variables_used_by_instabug.add(var_name)
            
            # Track variables in group/name format with version: $variable or ${variable} (including variations)
            group_name_variable_pattern = rf'group\s*:\s*["\']com\.instabug\.library(?:-[^"]*)?["\']\s*,\s*name\s*:\s*["\']({re.escape(old_name)})["\']\s*,\s*version\s*:\s*\$\{{?([a-zA-Z_][a-zA-Z0-9_]*)\}}?'
            for match in re.finditer(group_name_variable_pattern, content):
                var_name = match.group(2)
                variables_used_by_instabug.add(var_name)
        
        # Also check for generic com.instabug.library dependencies with variables (both $var and ${var} formats, including variations)
        generic_instabug_pattern = r'["\']com\.instabug\.library(?:-[^:]*)?:[^:]+:\$\{?([a-zA-Z_][a-zA-Z0-9_]*)\}?["\']'
        for match in re.finditer(generic_instabug_pattern, content):
            var_name = match.group(1)
            variables_used_by_instabug.add(var_name)
        
        # Now perform the migrations
        
        # 1. Migrate group references (preserving variations)
        def replace_group_reference(match):
            # Extract the full group including any variation
            full_match = match.group(0)
            # Find the group value
            group_match = re.search(r'["\']com\.instabug\.library(-[^"\']*)?["\']', full_match)
            if group_match:
                variation = group_match.group(1) if group_match.group(1) else ""
                return full_match.replace(group_match.group(0), f'"ai.luciq.library{variation}"')
            return full_match
        
        new_content, count = re.subn(
            r'group\s*:\s*["\']com\.instabug\.library(?:-[^"\']*)?["\']',
            replace_group_reference,
            modified_content
        )
        modified_content = new_content
        replacements += count
        
        # 2. Migrate name references using artifact mappings
        for old_name, new_name in self.artifact_mappings.items():
            # Handle name: "artifact" format
            new_content, count = re.subn(
                rf'name\s*:\s*["\']({re.escape(old_name)})["\']',
                f'name: "{new_name}"',
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            # Handle "com.instabug.library:artifact:version" format (preserve variables and variations)
            def replace_dependency_preserve_variables(match):
                quote = match.group(1)
                full_group = match.group(2)  # This includes the variation if present
                artifact = match.group(3)
                version_part = match.group(4)
                
                # Extract variation from the group
                group_match = re.match(r'com\.instabug\.library(-[^:]*)?', full_group)
                variation = group_match.group(1) if group_match and group_match.group(1) else ""
                
                # If it's a variable reference (starts with $ or ${), preserve it
                if version_part.startswith('$'):
                    return f'{quote}ai.luciq.library{variation}:{new_name}:{version_part}{quote}'
                else:
                    # If it's a hardcoded version, update it
                    return f'{quote}ai.luciq.library{variation}:{new_name}:{self.luciq_version}{quote}'
            
            new_content, count = re.subn(
                rf'(["\'])(com\.instabug\.library(?:-[^:]*)?):({re.escape(old_name)}):([^"\']+)\1',
                replace_dependency_preserve_variables,
                modified_content
            )
            modified_content = new_content
            replacements += count
        
        # 3. Update version variable declarations that are actually used by Instabug dependencies
        # Only update variables that we tracked as being used by Instabug dependencies
        # Track which variables actually had their declarations updated
        variables_with_updated_declarations = set()
        
        for var_name in variables_used_by_instabug:
            # Handle different variable declaration formats
            var_patterns = [
                rf'(def\s+{re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])',
                rf'({re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])',
                rf'(val\s+{re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])'
            ]
            
            for pattern in var_patterns:
                def replace_tracked_variable(match):
                    prefix = match.group(1)
                    old_version = match.group(2)
                    suffix = match.group(3)
                    return f'{prefix}{self.luciq_version}{suffix}'
                
                new_content, count = re.subn(pattern, replace_tracked_variable, modified_content)
                modified_content = new_content
                replacements += count
                
                # If we found and updated this variable's declaration, track it
                if count > 0:
                    variables_with_updated_declarations.add(var_name)
        
        # 4. FALLBACK: Replace any remaining variable references in ai.luciq.library dependencies
        # If a variable was not trackable (declaration not found), replace the variable reference directly
        # BUT exclude variables that had their declarations successfully updated
        fallback_variable_pattern = rf'(["\']ai\.luciq\.library:[^:]*:)\$\{{?([a-zA-Z_][a-zA-Z0-9_]*)\}}?(["\'])'
        def replace_untrackable_variable(match):
            prefix = match.group(1)
            var_name = match.group(2)
            suffix = match.group(3)
            
            # Skip variables that had their declarations successfully updated - they should be preserved
            if var_name in variables_with_updated_declarations:
                return match.group(0)  # Return original match unchanged
            
            # Log that we're using fallback for this variable
            if self.file_logger:
                self.file_logger.log(f"FALLBACK: Variable ${var_name} not trackable, replacing with {self.luciq_version}", to_console=not self.suppress_detailed_output)
            return f'{prefix}{self.luciq_version}{suffix}'
        
        new_content, count = re.subn(fallback_variable_pattern, replace_untrackable_variable, modified_content)
        modified_content = new_content
        replacements += count
        
        # 5. Update direct version references to Luciq version (only hardcoded versions, not variables)
        # Match any hardcoded version in ai.luciq.library dependencies and update to current version
        version_pattern = rf'(["\']ai\.luciq\.library:[^:]*:)([^"\'$]+)(["\'])'
        new_content, count = re.subn(
            version_pattern,
            rf'\g<1>{self.luciq_version}\g<3>',
            modified_content
        )
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _migrate_plugin_declarations(self, content: str) -> Tuple[str, int]:
        """Migrate plugin declarations in plugins block"""
        modified_content = content
        replacements = 0
        
        # Plugin ID patterns for com.instabug.library (preserving variations) with version handling
        # Handle id("com.instabug.library") version "version" format (preserving variations)
        plugin_with_version_pattern = r'id\s*\(\s*["\']com\.instabug\.library(-[^"\']*)?["\']\s*\)\s+version\s+["\']([^"\']+)["\']'
        def replace_plugin_with_version(match):
            variation = match.group(1) if match.group(1) else ""
            old_version = match.group(2)
            return f'id("ai.luciq.library{variation}") version "{self.luciq_version}"'
        
        new_content, count = re.subn(plugin_with_version_pattern, replace_plugin_with_version, modified_content)
        modified_content = new_content
        replacements += count
        
        # Handle id "com.instabug.library" version "version" format (preserving variations)
        plugin_with_version_pattern_quotes = r'id\s+["\']com\.instabug\.library(-[^"\']*)?["\']\s+version\s+["\']([^"\']+)["\']'
        def replace_plugin_with_version_quotes(match):
            variation = match.group(1) if match.group(1) else ""
            old_version = match.group(2)
            return f'id "ai.luciq.library{variation}" version "{self.luciq_version}"'
        
        new_content, count = re.subn(plugin_with_version_pattern_quotes, replace_plugin_with_version_quotes, modified_content)
        modified_content = new_content
        replacements += count
        
        # Fallback patterns for plugin IDs without explicit version (preserving variations)
        # Handle id "com.instabug.library" (without version, preserving variations)
        def replace_plugin_id_quotes(match):
            variation = match.group(1) if match.group(1) else ""
            return f'id "ai.luciq.library{variation}"'
        
        new_content, count = re.subn(
            r'id\s+["\']com\.instabug\.library(-[^"\']*)?["\'](?!\s+version)',
            replace_plugin_id_quotes,
            modified_content
        )
        modified_content = new_content
        replacements += count
        
        # Handle id("com.instabug.library") (without version, preserving variations)
        def replace_plugin_id_parens(match):
            variation = match.group(1) if match.group(1) else ""
            return f'id("ai.luciq.library{variation}")'
        
        new_content, count = re.subn(
            r'id\s*\(\s*["\']com\.instabug\.library(-[^"\']*)?["\']\s*\)(?!\s+version)',
            replace_plugin_id_parens,
            modified_content
        )
        modified_content = new_content
        replacements += count
        
        # Handle apply plugin patterns using artifact mappings
        for old_name, new_name in self.artifact_mappings.items():
            # apply plugin: "instabug-xxx"
            new_content, count = re.subn(
                rf'apply\s+plugin\s*:\s*["\']({re.escape(old_name)})["\']',
                f'apply plugin: "{new_name}"',
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            # id("instabug-xxx") version "version" - with version
            plugin_artifact_with_version_pattern = rf'id\s*\(\s*["\']({re.escape(old_name)})["\']\s*\)\s+version\s+["\']([^"\']+)["\']'
            def replace_artifact_plugin_with_version(match):
                old_version = match.group(2)
                return f'id("{new_name}") version "{self.luciq_version}"'
            
            new_content, count = re.subn(plugin_artifact_with_version_pattern, replace_artifact_plugin_with_version, modified_content)
            modified_content = new_content
            replacements += count
            
            # id "instabug-xxx" version "version" - with version
            plugin_artifact_with_version_pattern_quotes = rf'id\s+["\']({re.escape(old_name)})["\']\s+version\s+["\']([^"\']+)["\']'
            def replace_artifact_plugin_with_version_quotes(match):
                old_version = match.group(2)
                return f'id "{new_name}" version "{self.luciq_version}"'
            
            new_content, count = re.subn(plugin_artifact_with_version_pattern_quotes, replace_artifact_plugin_with_version_quotes, modified_content)
            modified_content = new_content
            replacements += count
            
            # id("instabug-xxx") - parentheses with quotes (without version)
            new_content, count = re.subn(
                rf'id\s*\(\s*["\']({re.escape(old_name)})["\']\s*\)(?!\s+version)',
                f'id("{new_name}")',
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            # id "instabug-xxx" - quotes without parentheses (without version)
            new_content, count = re.subn(
                rf'id\s+["\']({re.escape(old_name)})["\'](?!\s+version)',
                f'id "{new_name}"',
                modified_content
            )
            modified_content = new_content
            replacements += count
            
            # id instabug-xxx - no quotes (less common but possible)
            new_content, count = re.subn(
                rf'id\s+({re.escape(old_name)})(?=\s|$)',
                f'id {new_name}',
                modified_content
            )
            modified_content = new_content
            replacements += count
        
        return modified_content, replacements

    def _migrate_buildscript_dependencies(self, content: str) -> Tuple[str, int]:
        """Migrate buildScript dependencies with variable tracking and fallback"""
        modified_content = content
        replacements = 0
        
        # FIRST: Track version variables that are actually used by Instabug buildscript dependencies
        variables_used_by_instabug = set()
        
        # Find buildscript dependencies that use com.instabug.library (and its variations) and track their version variables
        for old_name, new_name in self.artifact_mappings.items():
            # Track variables in "classpath 'com.instabug.library:artifact:$variable'" and "${variable}" formats (including variations)
            variable_usage_pattern = rf'classpath\s+["\']com\.instabug\.library(?:-[^:]*)?:{re.escape(old_name)}:\$\{{?([a-zA-Z_][a-zA-Z0-9_]*)\}}?["\']'
            for match in re.finditer(variable_usage_pattern, content):
                var_name = match.group(1)
                variables_used_by_instabug.add(var_name)
        
        # Handle buildscript classpath dependencies using artifact mappings (preserving variations)
        for old_name, new_name in self.artifact_mappings.items():
            # classpath "com.instabug.library:artifact:version" (preserve variables and variations)
            def replace_classpath_preserve_variables(match):
                quote = match.group(1)
                full_group = match.group(2)
                artifact = match.group(3)
                version_part = match.group(4)
                
                # Extract variation from the group
                group_match = re.match(r'com\.instabug\.library(-[^:]*)?', full_group)
                variation = group_match.group(1) if group_match and group_match.group(1) else ""
                
                # If it's a variable reference (starts with $), preserve it
                if version_part.startswith('$'):
                    return f'classpath {quote}ai.luciq.library{variation}:{new_name}:{version_part}{quote}'
                else:
                    # If it's a hardcoded version, update it
                    return f'classpath {quote}ai.luciq.library{variation}:{new_name}:{self.luciq_version}{quote}'
            
            pattern = rf'classpath\s+(["\'])(com\.instabug\.library(?:-[^:]*)?):({re.escape(old_name)}):([^"\']+)\1'
            new_content, count = re.subn(pattern, replace_classpath_preserve_variables, modified_content)
            modified_content = new_content
            replacements += count
        
        # Update version variable declarations that are actually used by Instabug buildscript dependencies
        # Track which variables actually had their declarations updated
        variables_with_updated_declarations = set()
        
        for var_name in variables_used_by_instabug:
            # Handle different variable declaration formats
            var_patterns = [
                rf'(def\s+{re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])',
                rf'({re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])',
                rf'(val\s+{re.escape(var_name)}\s*=\s*["\'])([^"\']+)(["\'])'
            ]
            
            for pattern in var_patterns:
                def replace_tracked_variable(match):
                    prefix = match.group(1)
                    old_version = match.group(2)
                    suffix = match.group(3)
                    return f'{prefix}{self.luciq_version}{suffix}'
                
                new_content, count = re.subn(pattern, replace_tracked_variable, modified_content)
                modified_content = new_content
                replacements += count
                
                # If we found and updated this variable's declaration, track it
                if count > 0:
                    variables_with_updated_declarations.add(var_name)
        
        # FALLBACK: Replace any remaining variable references in ai.luciq.library buildscript dependencies
        fallback_variable_pattern = rf'(classpath\s+["\']ai\.luciq\.library:[^:]*:)\$\{{?([a-zA-Z_][a-zA-Z0-9_]*)\}}?(["\'])'
        def replace_untrackable_buildscript_variable(match):
            prefix = match.group(1)
            var_name = match.group(2)
            suffix = match.group(3)
            
            # Skip variables that had their declarations successfully updated - they should be preserved
            if var_name in variables_with_updated_declarations:
                return match.group(0)  # Return original match unchanged
            
            # Log that we're using fallback for this variable
            if self.file_logger:
                self.file_logger.log(f"FALLBACK: Buildscript variable ${var_name} not trackable, replacing with {self.luciq_version}", to_console=not self.suppress_detailed_output)
            return f'{prefix}{self.luciq_version}{suffix}'
        
        new_content, count = re.subn(fallback_variable_pattern, replace_untrackable_buildscript_variable, modified_content)
        modified_content = new_content
        replacements += count
        
        return modified_content, replacements

    def _migrate_plugin_configurations(self) -> bool:
        """Migrate plugin configuration blocks"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating plugin configurations...")
        else:
            logger.info("Migrating plugin configurations...")
        
        gradle_files = list(self.project_path.rglob("build.gradle*"))
        gradle_files = self._filter_files_by_skip_dirs(gradle_files)
        
        success = True
        for gradle_file in gradle_files:
            if not self._migrate_plugin_config_file(gradle_file):
                success = False
                
        return success

    def _migrate_plugin_config_file(self, gradle_file: Path) -> bool:
        """Migrate plugin configurations in a single file"""
        try:
            with open(gradle_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            if 'Instabug' not in content and 'instabug' not in content:
                return True
                
            original_content = content
            modified_content = content
            replacements = 0
            
            # Parse and migrate configuration blocks
            modified_content, config_replacements = self._migrate_configuration_blocks(modified_content)
            replacements += config_replacements
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY CONFIG: {gradle_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY CONFIG: {gradle_file} ({replacements} replacements)")
                    self._show_config_changes(gradle_file, original_content, modified_content)
                else:
                    with open(gradle_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified config in {gradle_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating plugin config in {gradle_file}: {e}")
            self.stats['errors'] += 1
            return False

    def _migrate_configuration_blocks(self, content: str) -> Tuple[str, int]:
        """Hybrid approach: 12-step logic for legacy blocks + structure preservation for complex nested content"""
        modified_content = content
        replacements = 0
        
        # Find all Instabug and instabug configuration blocks
        instabug_blocks = self._find_configuration_blocks(modified_content, 'Instabug')
        instabug_lowercase_blocks = self._find_configuration_blocks(modified_content, 'instabug')
        
        if not instabug_blocks and not instabug_lowercase_blocks:
            return modified_content, 0
        
        # Step 1: If neither blocks are defined, do nothing (already handled above)
        
        # Step 2: If Instabug block is defined but instabug block is not, add instabug block
        if instabug_blocks and not instabug_lowercase_blocks:
            # Simple transformation: convert legacy block to modern block
            for block in instabug_blocks:
                legacy_block_full = block.group(0)
                legacy_content = block.group(1)
                
                # Apply basic transformations to legacy content
                transformed_content = self._transform_legacy_block_content(legacy_content)
                
                # Create new instabug block
                new_block = f"instabug {{\n{transformed_content}\n}}"
                modified_content = modified_content.replace(legacy_block_full, new_block)
                replacements += 1
        
        # Step 3: If instabug block has apm, remove all Instabug blocks
        elif instabug_lowercase_blocks and instabug_blocks:
            # Check if any instabug block has apm
            has_apm = False
            for lowercase_block in instabug_lowercase_blocks:
                if 'apm {' in lowercase_block.group(1) or 'apm{' in lowercase_block.group(1):
                    has_apm = True
                    break
            
            if has_apm:
                # Step 3: Remove all legacy Instabug blocks
                for legacy_block in instabug_blocks:
                    modified_content = modified_content.replace(legacy_block.group(0), '')
                    replacements += 1
            else:
                # Step 4: Merge legacy APM into instabug blocks
                for legacy_block in instabug_blocks:
                    legacy_content = legacy_block.group(1)
                    if 'APM {' in legacy_content or 'APM{' in legacy_content:
                        # Transform legacy APM content
                        transformed_apm = self._transform_legacy_apm_block(legacy_content)
                        
                        # Add to first instabug block
                        if instabug_lowercase_blocks:
                            first_block = instabug_lowercase_blocks[0]
                            original_content = first_block.group(1)
                            merged_content = original_content + '\n\n    ' + transformed_apm
                            
                            new_block = f"instabug {{\n{merged_content}\n}}"
                            modified_content = modified_content.replace(first_block.group(0), new_block)
                            replacements += 1
                    
                    # Remove legacy block
                    modified_content = modified_content.replace(legacy_block.group(0), '')
                    replacements += 1
        
        # Steps 9-11: Apply transformation rules to remaining instabug blocks (modern-only case)
        remaining_blocks = self._find_configuration_blocks(modified_content, 'instabug')
        for block in remaining_blocks:
            block_content = block.group(1)
            transformed_content = self._apply_modern_block_transformations(block_content)
            
            if transformed_content != block_content:
                new_block = f"instabug {{\n{transformed_content}\n}}"
                modified_content = modified_content.replace(block.group(0), new_block)
                replacements += 1
        
        # Step 12: Finally, rename instabug blocks to luciq (preserves all internal structure)
        # Use simple string replacement to preserve complex nested structures
        modified_content = re.sub(r'\binstabug\s*\{', 'luciq {', modified_content)
        if 'luciq {' in modified_content and 'instabug {' not in modified_content:
            replacements += 1
        
        return modified_content, replacements
    
    def _transform_legacy_block_content(self, legacy_content: str) -> str:
        """Transform legacy block content following the 12-step migration process"""
        # Extract debugEnabled value first before any transformations
        debug_enabled_match = re.search(r'debugEnabled\s*\(\s*([^)]+)\s*\)', legacy_content)
        debug_value = debug_enabled_match.group(1).strip() if debug_enabled_match else None
        
        # Step 5: Transform APM block name to lowercase
        transformed = re.sub(r'\bAPM\s*\{', 'apm {', legacy_content)
        
        # Step 6-7: Transform function calls to assignments
        transformed = re.sub(r'networkInterceptingEnabled\s*\(\s*([^)]+)\s*\)', r'networkEnabled = \1', transformed)
        transformed = re.sub(r'fragmentSpansEnabled\s*\(\s*([^)]+)\s*\)', r'fragmentSpansEnabled = \1', transformed)
        
        # Step 9-11: Remove debugEnabled from apm block (it will be moved to root level)
        if debug_value:
            transformed = re.sub(r'\s*debugEnabled\s*\(\s*[^)]+\s*\)\s*\n?', '', transformed)
        
        # Clean up formatting and build the final structure
        lines = []
        
        # Add setDebugLogsEnabled at root level if we extracted it
        if debug_value:
            lines.append(f"    setDebugLogsEnabled({debug_value})")
        
        # Process the apm block content
        apm_match = re.search(r'apm\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}', transformed, re.DOTALL)
        if apm_match:
            apm_content = apm_match.group(1).strip()
            if apm_content:
                lines.append("    apm {")
                # Add each line of apm content with proper indentation
                for line in apm_content.split('\n'):
                    line = line.strip()
                    if line:
                        lines.append(f"        {line}")
                lines.append("    }")
        
        return '\n'.join(lines)
    
    def _apply_modern_block_transformations(self, block_content: str) -> str:
        """Apply Steps 9-11 transformations to modern instabug blocks"""
        lines = block_content.split('\n')
        result_lines = []
        in_apm_block = False
        apm_brace_count = 0
        debug_enabled_value = None
        has_set_debug_logs = 'setDebugLogsEnabled' in block_content
        
        # First pass: analyze the content
        for line in lines:
            stripped = line.strip()
            
            # Track if we're inside an apm block
            if 'apm {' in stripped:
                in_apm_block = True
                apm_brace_count = stripped.count('{') - stripped.count('}')
            elif in_apm_block:
                apm_brace_count += stripped.count('{') - stripped.count('}')
                
                # Check if this line contains debugEnabled
                debug_match = re.match(r'\s*debugEnabled\s*=\s*(true|false)\s*,?\s*$', stripped)
                if debug_match:
                    debug_enabled_value = debug_match.group(1)
                
                # Check if we've exited the apm block
                if apm_brace_count <= 0:
                    in_apm_block = False
        
        # Second pass: apply transformations
        in_apm_block = False
        apm_brace_count = 0
        added_set_debug_logs = False
        
        for line in lines:
            stripped = line.strip()
            
            # Track if we're inside an apm block
            if 'apm {' in stripped:
                in_apm_block = True
                apm_brace_count = stripped.count('{') - stripped.count('}')
                result_lines.append(line)
            elif in_apm_block:
                apm_brace_count += stripped.count('{') - stripped.count('}')
                
                # Check if this line contains debugEnabled
                debug_match = re.match(r'\s*debugEnabled\s*=\s*(true|false)\s*,?\s*$', stripped)
                if debug_match:
                    debug_value = debug_match.group(1)
                    
                    # Step 11: If debugEnabled = false, just remove it
                    if debug_value == 'false':
                        continue  # Skip this line
                    
                    # Step 9: If debugEnabled = true and no setDebugLogsEnabled at root, add it
                    elif debug_value == 'true' and not has_set_debug_logs and not added_set_debug_logs:
                        # Add setDebugLogsEnabled(true) at the beginning of the block
                        result_lines.insert(0, '    setDebugLogsEnabled(true)')
                        added_set_debug_logs = True
                        continue  # Skip the debugEnabled line
                    
                    # Step 9: If debugEnabled = true and setDebugLogsEnabled exists, just remove debugEnabled
                    elif debug_value == 'true' and has_set_debug_logs:
                        continue  # Skip this line
                else:
                    result_lines.append(line)
                
                # Check if we've exited the apm block
                if apm_brace_count <= 0:
                    in_apm_block = False
            else:
                result_lines.append(line)
        
        return '\n'.join(result_lines)
    
    def _transform_legacy_apm_block(self, legacy_content: str) -> str:
        """Extract and transform APM block from legacy content"""
        # Find APM block
        apm_match = re.search(r'APM\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}', legacy_content, re.DOTALL)
        if apm_match:
            apm_content = apm_match.group(1).strip()
            
            # Transform function calls to assignments
            apm_content = re.sub(r'debugEnabled\s*\(\s*([^)]+)\s*\)', r'debugEnabled = \1', apm_content)
            apm_content = re.sub(r'networkInterceptingEnabled\s*\(\s*([^)]+)\s*\)', r'networkEnabled = \1', apm_content)
            apm_content = re.sub(r'fragmentSpansEnabled\s*\(\s*([^)]+)\s*\)', r'fragmentSpansEnabled = \1', apm_content)
            
            return f"apm {{\n        {apm_content}\n    }}"
        
        return ""
    
    def _find_configuration_blocks(self, content: str, block_name: str) -> List[re.Match]:
        """Find configuration blocks with proper nested brace handling"""
        matches = []
        pattern = rf'{re.escape(block_name)}\s*\{{'
        
        # Find all potential starting positions
        for match in re.finditer(pattern, content):
            start_pos = match.start()
            brace_start = match.end() - 1  # Position of the opening brace
            
            # Find the matching closing brace
            brace_count = 0
            pos = brace_start
            
            while pos < len(content):
                char = content[pos]
                if char == '{':
                    brace_count += 1
                elif char == '}':
                    brace_count -= 1
                    if brace_count == 0:
                        # Found the matching closing brace
                        full_match = content[start_pos:pos + 1]
                        block_content = content[brace_start + 1:pos]  # Content between braces
                        
                        # Create a match-like object
                        class ConfigMatch:
                            def __init__(self, full_text, content, start, end):
                                self.full_text = full_text
                                self.content = content
                                self.start_pos = start
                                self.end_pos = end
                            
                            def group(self, n):
                                if n == 0:
                                    return self.full_text
                                elif n == 1:
                                    return self.content
                                return None
                            
                            def start(self):
                                return self.start_pos
                            
                            def end(self):
                                return self.end_pos
                        
                        matches.append(ConfigMatch(full_match, block_content, start_pos, pos + 1))
                        break
                pos += 1
        
        logger.debug(f"Found {len(matches)} {block_name} configuration blocks")
        return matches

    def _parse_configuration_block_detailed(self, block_content: str) -> Dict[str, any]:
        """Parse configuration block content preserving original formatting"""
        configs = {}
        
        # Parse nested blocks (like APM/apm)
        nested_pattern = r'(\w+)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        for match in re.finditer(nested_pattern, block_content, re.DOTALL):
            block_name, nested_content = match.groups()
            configs[block_name.strip()] = self._parse_configuration_block_detailed(nested_content)
        
        # Remove nested blocks from content to avoid double parsing
        content_without_nested = re.sub(nested_pattern, '', block_content, flags=re.DOTALL)
        
        # Parse all configurations and preserve their original format
        # This captures various formats: key = value, key(value), key "value", etc.
        # Updated to handle { } values and inline comments properly
        all_config_pattern = r'^\s*(\w+)(?:\s*\(\s*([^)]+)\s*\)|\s*=\s*(\{[^}]*\}(?:\s*//.*)?|[^\n,}]+)|\s+([^\s\n,}=][^\n,}]*))(?:\s*,)?\s*$'
        
        for match in re.finditer(all_config_pattern, content_without_nested, re.MULTILINE):
            key = match.group(1).strip()
            func_value = match.group(2)  # value from function call with parentheses
            assign_value = match.group(3)  # value from assignment
            space_value = match.group(4)  # value from space-separated format
            
            if func_value is not None:
                # Function call format: key(value)
                configs[key] = {
                    'type': 'function_call_parens', 
                    'value': func_value.strip(),
                    'original_format': 'function_call_parens'
                }
            elif assign_value is not None:
                # Assignment format: key = value
                configs[key] = {
                    'type': 'assignment', 
                    'value': assign_value.strip().rstrip(','),
                    'original_format': 'assignment'
                }
            elif space_value is not None:
                # Space-separated format: key value
                configs[key] = {
                    'type': 'function_call_space', 
                    'value': space_value.strip().rstrip(','),
                    'original_format': 'function_call_space'
                }
        
        # Parse standalone comments to preserve them
        comment_pattern = r'^\s*(//.*)\s*$'
        comment_counter = 0
        for match in re.finditer(comment_pattern, content_without_nested, re.MULTILINE):
            comment_text = match.group(1).strip()
            # Use a unique key for each comment to preserve them
            comment_key = f'__comment_{comment_counter}__'
            configs[comment_key] = {
                'type': 'comment',
                'value': comment_text,
                'original_format': 'comment'
            }
            comment_counter += 1
        
        return configs

    def _apply_configuration_migration_rules(self, legacy_configs: Dict, new_configs: Dict) -> Dict:
        """Apply the 12-step migration rules from the guide (steps 1-11, step 12 is handled in block generation)"""
        final_configs = {}
        
        # Step 2: If Instabug block exists but instabug doesn't, create instabug block
        # Step 3: If instabug block exists with apm, remove Instabug block
        # Step 4: If instabug exists without apm but Instabug has APM, copy APM to instabug
        
        # Start with new configs as base (they take precedence in conflicts)
        final_configs.update(new_configs)
        
        # Process legacy configs
        for key, value in legacy_configs.items():
            # Step 5: Rename APM to apm
            if key == 'APM':
                key = 'apm'
            
            # If new configs don't have this key, add it from legacy
            if key not in final_configs:
                final_configs[key] = value
            # If both have the key, merge nested blocks
            elif isinstance(value, dict) and isinstance(final_configs[key], dict):
                final_configs[key] = self._merge_nested_configs(final_configs[key], value)
        
        # Apply specific transformation rules (Steps 6-11)
        final_configs = self._apply_transformation_rules(final_configs)
        
        return final_configs

    def _merge_nested_configs(self, new_config: Dict, legacy_config: Dict) -> Dict:
        """Merge nested configuration blocks, with new config taking precedence"""
        merged = {}
        
        # Add all legacy configs first
        for key, value in legacy_config.items():
            merged[key] = value
        
        # Override with new configs (new takes precedence)
        for key, value in new_config.items():
            merged[key] = value
        
        return merged

    def _apply_transformation_rules(self, configs: Dict) -> Dict:
        """Apply ONLY the specific transformation rules (steps 6-11), preserve everything else as-is"""
        transformed = {}
        debug_logs_enabled = None
        
        # Process each top-level configuration
        for key, value in configs.items():
            if key == 'apm' and isinstance(value, dict):
                # Process APM block transformations - ONLY apply specific transformations
                apm_config = {}
                apm_debug_enabled = None
                
                for apm_key, apm_value in value.items():
                    # Step 6: debugEnabled({value}) -> remove (will be moved to top level)
                    if apm_key == 'debugEnabled':
                        apm_debug_enabled = self._extract_clean_value(apm_value)
                        # Don't add debugEnabled to apm_config - it gets removed
                    
                    # Step 7: networkInterceptingEnabled({value}) -> networkEnabled = {value}
                    elif apm_key == 'networkInterceptingEnabled':
                        clean_value = self._extract_clean_value(apm_value)
                        apm_config['networkEnabled'] = {
                            'type': 'assignment',
                            'value': clean_value,
                            'original_format': 'assignment'
                        }
                    
                    # Step 8: fragmentSpansEnabled({value}) -> fragmentSpansEnabled = {value}
                    elif apm_key == 'fragmentSpansEnabled':
                        clean_value = self._extract_clean_value(apm_value)
                        # Convert function call format to assignment format
                        if isinstance(apm_value, dict) and apm_value.get('original_format') == 'function_call_parens':
                            apm_config['fragmentSpansEnabled'] = {
                                'type': 'assignment',
                                'value': clean_value,
                                'original_format': 'assignment'
                            }
                        else:
                            # Keep original format if it wasn't a function call
                            apm_config['fragmentSpansEnabled'] = apm_value
                    
                    else:
                        # Keep ALL other configurations exactly as-is with original formatting
                        apm_config[apm_key] = apm_value
                
                # Handle debugEnabled migration (Steps 9-11)
                if apm_debug_enabled is not None:
                    # Check if setDebugLogsEnabled exists at top level
                    set_debug_logs = configs.get('setDebugLogsEnabled')
                    if set_debug_logs is not None:
                        set_debug_logs_value = self._extract_clean_value(set_debug_logs)
                        
                        # Step 9: Both true -> remove apm's debugEnabled
                        if str(apm_debug_enabled).lower() == 'true' and str(set_debug_logs_value).lower() == 'true':
                            debug_logs_enabled = 'true'
                        # Step 10: apm true, top false -> set top to true, remove apm's
                        elif str(apm_debug_enabled).lower() == 'true' and str(set_debug_logs_value).lower() == 'false':
                            debug_logs_enabled = 'true'
                        # Step 11: apm false -> remove apm's debugEnabled
                        elif str(apm_debug_enabled).lower() == 'false':
                            debug_logs_enabled = set_debug_logs_value
                        else:
                            debug_logs_enabled = set_debug_logs_value
                    else:
                        # No top-level setDebugLogsEnabled, use apm's value
                        if str(apm_debug_enabled).lower() != 'false':
                            debug_logs_enabled = apm_debug_enabled
                
                if apm_config:
                    transformed['apm'] = apm_config
            
            # Handle setDebugLogsEnabled at top level
            elif key == 'setDebugLogsEnabled':
                if debug_logs_enabled is None:
                    debug_logs_enabled = self._extract_clean_value(value)
            
            # Handle debugEnabled -> setDebugLogsEnabled transformation (Step 6)
            elif key == 'debugEnabled':
                if debug_logs_enabled is None:
                    debug_logs_enabled = self._extract_clean_value(value)
                # Don't add debugEnabled to transformed - it becomes setDebugLogsEnabled
            
            else:
                # Keep ALL other top-level configurations exactly as-is with original formatting
                transformed[key] = value
        
        # Add setDebugLogsEnabled if we determined a value (always as function call)
        if debug_logs_enabled is not None:
            transformed['setDebugLogsEnabled'] = {
                'type': 'function_call_parens',
                'value': debug_logs_enabled,
                'original_format': 'function_call_parens'
            }
        
        return transformed

    def _generate_configuration_block_detailed(self, configs: Dict) -> str:
        """Generate configuration block content preserving original formatting"""
        lines = []
        
        for key, value in configs.items():
            if isinstance(value, dict) and not self._has_original_format(value):
                # Handle nested blocks
                nested_lines = []
                for nested_key, nested_value in value.items():
                    formatted_line = self._format_config_line(nested_key, nested_value, '        ')
                    nested_lines.append(formatted_line)
                
                if nested_lines:
                    lines.append(f'    {key} {{')
                    lines.extend(nested_lines)
                    lines.append('    }')
            else:
                # Handle simple key-value pairs
                formatted_line = self._format_config_line(key, value, '    ')
                if key == 'setDebugLogsEnabled':
                    lines.insert(0, formatted_line)  # setDebugLogsEnabled always at top
                else:
                    lines.append(formatted_line)
        
        return '\n'.join(lines)

    def _has_original_format(self, value) -> bool:
        """Check if a value has original formatting information"""
        return isinstance(value, dict) and 'original_format' in value

    def _format_config_line(self, key: str, value, indent: str) -> str:
        """Format a configuration line preserving original format"""
        clean_value = self._extract_clean_value(value)
        
        if isinstance(value, dict) and 'original_format' in value:
            original_format = value['original_format']
            
            if original_format == 'comment':
                # Handle standalone comments
                return f'{indent}{clean_value}'
            elif original_format == 'function_call_parens':
                return f'{indent}{key}({clean_value})'
            elif original_format == 'function_call_space':
                return f'{indent}{key} {clean_value}'
            elif original_format == 'assignment':
                return f'{indent}{key} = {clean_value}'
        
        # Fallback to assignment format if no original format info
        return f'{indent}{key} = {clean_value}'

    def _is_function_call_key(self, key: str, value) -> bool:
        """Determine if a key should be formatted as a function call"""
        # Check if the original value was explicitly parsed as a function call
        if isinstance(value, dict) and value.get('type') == 'function_call':
            return True
        
        # Special handling for setDebugLogsEnabled (always function call)
        if key == 'setDebugLogsEnabled':
            return True
        
        # Methods starting with 'set' and having uppercase after 'set' are function calls
        if key.startswith('set') and len(key) > 3 and key[3].isupper():
            return True
        
        # Methods ending with 'Url' are typically function calls (like uploadUrl)
        if key.endswith('Url'):
            return True
        
        return False

    def _extract_clean_value(self, value):
        """Extract clean value from potentially complex value structure"""
        if isinstance(value, dict):
            if 'value' in value:
                return value['value']
            elif 'type' in value and value['type'] in ['function_call_parens', 'function_call_space', 'assignment']:
                return value.get('value', value)
            else:
                return value
        else:
            return value

    def _parse_configuration_block(self, block_content: str) -> Dict[str, any]:
        """Parse configuration block content into a dictionary"""
        configs = {}
        
        # Parse simple key-value pairs
        kv_pattern = r'(\w+)\s*=\s*([^\n]+)'
        for match in re.finditer(kv_pattern, block_content):
            key, value = match.groups()
            configs[key.strip()] = value.strip()
        
        # Parse nested blocks (like APM)
        nested_pattern = r'(\w+)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        for match in re.finditer(nested_pattern, block_content, re.DOTALL):
            block_name, nested_content = match.groups()
            configs[block_name.strip()] = self._parse_configuration_block(nested_content)
        
        return configs

    def _generate_configuration_block(self, configs: Dict[str, any]) -> str:
        """Generate configuration block content from dictionary"""
        lines = []
        
        # Handle special mappings
        debug_enabled = False
        
        for key, value in configs.items():
            if key == 'APM' and isinstance(value, dict):
                # Handle APM block migration
                apm_lines = []
                for apm_key, apm_value in value.items():
                    if apm_key == 'debugEnabled':
                        debug_enabled = apm_value
                    else:
                        apm_lines.append(f'        {apm_key} = {apm_value}')
                
                if apm_lines:
                    lines.append('    apm {')
                    lines.extend(apm_lines)
                    lines.append('    }')
            elif key == 'debugEnabled':
                debug_enabled = value
            elif isinstance(value, dict):
                # Handle other nested blocks
                nested_lines = []
                for nested_key, nested_value in value.items():
                    nested_lines.append(f'        {nested_key} = {nested_value}')
                
                if nested_lines:
                    lines.append(f'    {key.lower()} {{')
                    lines.extend(nested_lines)
                    lines.append('    }')
            else:
                lines.append(f'    {key} = {value}')
        
        # Add debugLogsEnabled if we found debugEnabled in APM
        if debug_enabled:
            lines.insert(0, f'    debugLogsEnabled = {debug_enabled}')
        
        return '\n'.join(lines)


    def _show_toml_changes(self, file_path: Path, original: str, modified: str):
        """Show TOML file changes in dry-run mode"""
        self._show_file_changes(file_path, original, modified, "TOML")

    def _show_gradle_changes(self, file_path: Path, original: str, modified: str):
        """Show Gradle file changes in dry-run mode"""
        self._show_file_changes(file_path, original, modified, "Gradle")

    def _show_config_changes(self, file_path: Path, original: str, modified: str):
        """Show configuration changes in dry-run mode with semantic analysis"""
        self._show_semantic_config_changes(file_path, original, modified)

    def _show_semantic_config_changes(self, file_path: Path, original: str, modified: str):
        """Show only meaningful configuration changes, not formatting differences"""
        changes = []
        
        # Extract configuration blocks from both versions
        original_blocks = self._extract_config_blocks(original)
        modified_blocks = self._extract_config_blocks(modified)
        
        # Compare block names
        orig_block_names = set(original_blocks.keys())
        mod_block_names = set(modified_blocks.keys())
        
        # Block name changes (e.g., instabug -> luciq)
        if orig_block_names != mod_block_names:
            removed = orig_block_names - mod_block_names
            added = mod_block_names - orig_block_names
            
            # Track which blocks have been matched
            matched_old = set()
            matched_new = set()
            
            for old_name in removed:
                for new_name in added:
                    if new_name not in matched_new and self._are_equivalent_blocks(original_blocks[old_name], modified_blocks[new_name]):
                        changes.append(f"Configuration block renamed: {old_name} → {new_name}")
                        matched_old.add(old_name)
                        matched_new.add(new_name)
                        break
            
            # Report any unmatched removals or additions
            unmatched_removed = removed - matched_old
            unmatched_added = added - matched_new
            
            for block_name in unmatched_removed:
                changes.append(f"Configuration block removed: {block_name}")
            
            for block_name in unmatched_added:
                changes.append(f"Configuration block added: {block_name}")
        
        # Look for content changes within blocks
        for block_name in mod_block_names:
            if block_name in original_blocks:
                block_changes = self._compare_block_contents(
                    original_blocks[block_name], 
                    modified_blocks[block_name]
                )
                changes.extend([f"  {change}" for change in block_changes])
        
        # Display the meaningful changes
        if changes:
            for change in changes:
                if self.file_logger:
                    self.file_logger.log(f"  {change}", to_console=not self.suppress_detailed_output)
                else:
                    logger.info(f"  {change}")
        else:
            # If no semantic changes detected, show a summary message
            if self.file_logger:
                self.file_logger.log("  Configuration block updated (properties may have been reordered)", to_console=not self.suppress_detailed_output)
            else:
                logger.info("  Configuration block updated (properties may have been reordered)")

    def _extract_config_blocks(self, content: str) -> Dict[str, str]:
        """Extract configuration blocks and their content"""
        blocks = {}
        
        # Find all configuration blocks
        patterns = [
            r'(Instabug)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}',
            r'(instabug)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}',
            r'(luciq)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        ]
        
        for pattern in patterns:
            for match in re.finditer(pattern, content, re.DOTALL):
                block_name, block_content = match.groups()
                blocks[block_name] = block_content.strip()
        
        return blocks

    def _are_equivalent_blocks(self, content1: str, content2: str) -> bool:
        """Check if two configuration blocks are semantically equivalent"""
        # Normalize whitespace and compare essential content
        norm1 = re.sub(r'\s+', ' ', content1.strip())
        norm2 = re.sub(r'\s+', ' ', content2.strip())
        
        # Allow for some differences in property ordering and formatting
        # This is a simplified check - could be made more sophisticated
        return len(norm1) > 0 and len(norm2) > 0 and abs(len(norm1) - len(norm2)) < len(norm1) * 0.3

    def _compare_block_contents(self, original: str, modified: str) -> List[str]:
        """Compare configuration block contents and return meaningful changes"""
        changes = []
        
        # This is a simplified implementation - could be enhanced to detect
        # specific property changes, additions, removals, etc.
        if original.strip() != modified.strip():
            # For now, just indicate that content was modified
            changes.append("Configuration properties updated")
        
        return changes

    def _show_file_changes(self, file_path: Path, original: str, modified: str, file_type: str):
        """Show file changes in dry-run mode"""
        original_lines = original.splitlines()
        modified_lines = modified.splitlines()
        
        for i, (orig_line, mod_line) in enumerate(zip(original_lines, modified_lines)):
            if orig_line != mod_line:
                if self.file_logger:
                    # Log to file and suppress console output when output file is specified
                    self.file_logger.log(f"  Line {i+1}: {orig_line.strip()}", to_console=not self.suppress_detailed_output)
                    self.file_logger.log(f"       →  {mod_line.strip()}", to_console=not self.suppress_detailed_output)
                else:
                    # Normal console output when no output file
                    logger.info(f"  Line {i+1}: {orig_line.strip()}")
                    logger.info(f"       →  {mod_line.strip()}")

    def _migrate_buildsrc_files(self) -> bool:
        """Migrate buildSrc Kotlin files for dependency definitions"""
        if self.file_logger:
            self.file_logger.log_step_header("Migrating buildSrc files...")
        else:
            logger.info("Migrating buildSrc files...")
        
        success = True
        
        # Find buildSrc directories
        buildsrc_dirs = []
        for root, dirs, files in os.walk(self.project_path):
            if 'buildSrc' in dirs:
                buildsrc_path = Path(root) / 'buildSrc'
                buildsrc_dirs.append(buildsrc_path)
        
        if not buildsrc_dirs:
            logger.info("No buildSrc directories found")
            return True
        
        logger.info(f"Found {len(buildsrc_dirs)} buildSrc directories: {[str(d) for d in buildsrc_dirs]}")
        
        # Process each buildSrc directory
        for buildsrc_dir in buildsrc_dirs:
            if not self._migrate_buildsrc_directory(buildsrc_dir):
                success = False
        
        return success
    
    def _migrate_buildsrc_directory(self, buildsrc_dir: Path) -> bool:
        """Migrate a single buildSrc directory"""
        success = True
        
        # Find all Java and Kotlin files in buildSrc (excluding .kts files which are Gradle scripts)
        source_files = []
        source_files.extend(buildsrc_dir.rglob("*.kt"))  # Kotlin files
        source_files.extend(buildsrc_dir.rglob("*.java"))  # Java files
        
        if not source_files:
            logger.info(f"No Java/Kotlin source files found in {buildsrc_dir}")
            return True
        
        logger.info(f"Processing {len(source_files)} Java/Kotlin source files in {buildsrc_dir}")
        
        for source_file in source_files:
            if not self._migrate_buildsrc_source_file(source_file):
                success = False
        
        return success
    
    def _migrate_buildsrc_source_file(self, source_file: Path) -> bool:
        """Migrate a single buildSrc Java/Kotlin source file using simplified pattern-based approach"""
        try:
            self.stats['files_processed'] += 1
            
            # Skip dry-run output files
            if self._is_dry_run_output_file(source_file):
                logger.info(f"Skipping {source_file.name} - detected as dry-run output file")
                return True
            
            with open(source_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Skip files that don't contain Instabug references
            if 'instabug' not in content.lower():
                return True
            
            original_content = content
            modified_content = content
            replacements = 0
            
            # Step 1: Version variable declarations (case-insensitive)
            # val instabugVersion = "16.0.1" → val instabugVersion = "18.0.0"
            # const val IBG_VERSION = "16.0.1" → const val IBG_VERSION = "18.0.0"
            version_var_pattern = r'((?:val|var|const\s+val)\s+\w*(?:instabug|ibg)\w*\s*=\s*["\'])\d+\.\d+\.\d+(["\'])'
            new_content, count = re.subn(version_var_pattern, rf'\g<1>{self.luciq_version}\g<2>', modified_content, flags=re.IGNORECASE)
            modified_content = new_content
            replacements += count
            
            # Step 2: Full dependency declarations (preserving variations)
            # "com.instabug.library:instabug:16.0.1" → "ai.luciq.library:luciq:18.0.0"
            # "com.instabug.library-verizon:instabug:16.0.1" → "ai.luciq.library-verizon:luciq:18.0.0"
            def replace_full_dependency(match):
                quote = match.group(1)
                full_group = match.group(2)
                artifact = match.group(3)
                
                # Extract variation from the group
                group_match = re.match(r'com\.instabug\.library(-[^:]*)?', full_group)
                variation = group_match.group(1) if group_match and group_match.group(1) else ""
                
                # Map artifact name
                new_artifact = self.artifact_mappings.get(artifact, artifact)
                return f'{quote}ai.luciq.library{variation}:{new_artifact}:{self.luciq_version}{quote}'
            
            full_dep_pattern = r'(["\'])(com\.instabug\.library(?:-[^:]*)?):([^:]+):\d+\.\d+\.\d+\1'
            new_content, count = re.subn(full_dep_pattern, replace_full_dependency, modified_content)
            modified_content = new_content
            replacements += count
            
            # Step 3: General string literal replacements
            # Replace substrings within all quoted string literals
            def replace_string_literals(match):
                quote = match.group(1)
                string_content = match.group(2)
                original_content = string_content
                
                # Replace group name: com.instabug.library (preserving variations) → ai.luciq.library
                import re as inner_re
                def replace_group_in_string(match):
                    variation = match.group(1) if match.group(1) else ""
                    return f'ai.luciq.library{variation}'
                
                string_content = inner_re.sub(r'com\.instabug\.library(-[^"\':\s]*)?', replace_group_in_string, string_content)
                
                # Replace artifact names using mappings (only in dependency contexts)
                # Use word boundaries and context-aware replacement to avoid changing variable names
                for old_name, new_name in self.artifact_mappings.items():
                    # Replace artifact names in dependency contexts like "group:artifact" or "group:artifact:"
                    # But avoid replacing in variable names like "instabug_version"
                    import re as inner_re
                    
                    # Pattern 1: group:artifact (at end of string or followed by : or space)
                    pattern1 = rf'(ai\.luciq\.library:){re.escape(old_name)}(?=:|$|\s)'
                    string_content = inner_re.sub(pattern1, rf'\1{new_name}', string_content)
                    
                    # Pattern 2: standalone artifact name (surrounded by word boundaries, not part of variable names)
                    # Only replace if it's a quoted standalone artifact, not part of variable names with underscores
                    if old_name in string_content:
                        # Check if it's a standalone artifact (not part of a variable name with underscores)
                        pattern2 = rf'\b{re.escape(old_name)}\b(?!_)'
                        string_content = inner_re.sub(pattern2, new_name, string_content)
                
                return f'{quote}{string_content}{quote}'
            
            # Pattern to match all string literals (double and single quotes)
            # Handles escaped quotes within strings
            string_literal_pattern = r'(["\'])((?:\\.|(?!\1)[^\\])*)\1'
            new_content, count = re.subn(string_literal_pattern, replace_string_literals, modified_content)
            modified_content = new_content
            replacements += count
            
            if replacements > 0:
                if self.dry_run:
                    if self.file_logger:
                        self.file_logger.log(f"WOULD MODIFY: {source_file} ({replacements} replacements)", to_console=not self.suppress_detailed_output)
                    else:
                        logger.info(f"WOULD MODIFY: {source_file} ({replacements} replacements)")
                    self._show_buildsrc_changes(source_file, original_content, modified_content)
                else:
                    with open(source_file, 'w', encoding='utf-8') as f:
                        f.write(modified_content)
                    logger.info(f"Modified {source_file} ({replacements} replacements)")
                
                self.stats['files_modified'] += 1
                self.stats['replacements_made'] += replacements
            
            return True
            
        except Exception as e:
            logger.error(f"Error migrating buildSrc file {source_file}: {e}")
            self.stats['errors'] += 1
            return False
    
    def _is_dry_run_output_file(self, file_path: Path) -> bool:
        """Check if a file is a dry-run output file by examining its header"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                first_line = f.readline().strip()
                return first_line.startswith("# Instabug to Luciq Migration Dry Run Output")
        except (UnicodeDecodeError, IOError):
            return False

    def _show_buildsrc_changes(self, file_path: Path, original_content: str, modified_content: str):
        """Show changes made to buildSrc files"""
        if original_content == modified_content:
            return
            
        original_lines = original_content.splitlines()
        modified_lines = modified_content.splitlines()
        
        for i, (orig_line, mod_line) in enumerate(zip(original_lines, modified_lines)):
            if orig_line != mod_line:
                if self.file_logger:
                    self.file_logger.log(f"  Line {i+1}: {orig_line.strip()}", to_console=not self.suppress_detailed_output)
                    self.file_logger.log(f"       →  {mod_line.strip()}", to_console=not self.suppress_detailed_output)
                else:
                    # Normal console output when no output file
                    logger.info(f"  Line {i+1}: {orig_line.strip()}")
                    logger.info(f"       →  {mod_line.strip()}")

    def get_stats(self) -> Dict[str, int]:
        """Get migration statistics"""
        return self.stats.copy()
