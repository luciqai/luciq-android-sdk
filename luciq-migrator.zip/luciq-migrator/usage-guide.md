# Migrating from Instabug to Luciq

## Overview

This guide helps you migrate your Android project from Instabug SDK to Luciq SDK using our automated migration script.

## Quick Start

### Requirements

- **Python 3.6+** (no external dependencies required)
- **Instabug SDK version**: 16.x.x

### Before You Start

1. **Backup your project** - Commit all changes to version control
2. **Clean build** - Run `./gradlew clean` to ensure a clean state
3. **Verify current setup** - Ensure your project builds successfully

## Using the Migration Script

### Step 1: Setup

1. Extract `luciq-migrator.zip` in your project root:
   ```bash
   cd /path/to/your/android/project
   unzip luciq-migrator.zip
   ```

2. Make the script executable:
   ```bash
   chmod +x luciq-migrator/migrate-to-luciq.sh
   ```

### Step 2: Preview Changes (Recommended)

Always preview changes before applying them:

```bash
./luciq-migrator/migrate-to-luciq.sh --dry-run
```

This shows you what will be changed without making any modifications.

**Save preview to file** (useful for large projects):

```bash
./luciq-migrator/migrate-to-luciq.sh --dry-run --output-file migration-preview.txt
```

This creates a detailed report of all changes that would be made, saved to the specified file.

### Step 3: Run Migration

```bash
./luciq-migrator/migrate-to-luciq.sh
```

The script will:
- Create an automatic backup in `migration-backup/`
- Migrate all files according to the mapping rules
- Provide detailed statistics

### Step 4: Verify Migration

```bash
# Check for any remaining Instabug references
grep -r "com\.instabug" . --exclude-dir=migration-backup

# Build your project
./gradlew clean build
```

## What Gets Migrated

The script automatically handles:

- **Dependencies**: `com.instabug.library` → `ai.luciq.library`
- **Versions**: Instabug 16.x.x → Luciq latest version
- **Plugin IDs**: `instabug` → `luciq`
- **Package imports**: `com.instabug.*` → `ai.luciq.*`
- **Class names**: `Instabug` → `Luciq`, `IBGNonFatalException` → `LuciqNonFatalException`
- **Method names**: `isInstabugNotification()` → `isLuciqNotification()`
- **Manifest entries**: `com.instabug.APP_TOKEN` → `ai.luciq.APP_TOKEN`
- **Resource files**: `instabug_config.json` → `luciq_config.json`
- **ProGuard rules**: Package references

## Script Options

| Option               | Description                                              |
|----------------------|----------------------------------------------------------|
| `--help`             | Show help and usage examples                             |
| `--dry-run`          | Preview changes without applying them                    |
| `--output-file FILE` | Write dry-run output to FILE (only works with --dry-run) |
| `--source-only`      | Migrate only source code (skip Gradle files)             |
| `--no-backup`        | Skip automatic backup creation                           |

### Examples

```bash
# Preview changes
./luciq-migrator/migrate-to-luciq.sh --dry-run

# Preview changes and save to file
./luciq-migrator/migrate-to-luciq.sh --dry-run --output-file migration-preview.txt

# Full migration with backup
./luciq-migrator/migrate-to-luciq.sh

# Source code only (if Gradle already migrated)
./luciq-migrator/migrate-to-luciq.sh --source-only

# Migrate specific project
./luciq-migrator/migrate-to-luciq.sh /path/to/project
```

## Troubleshooting

### Common Issues

**Build fails after migration**
- Run `./gradlew clean build` to clear cache
- Check that all Instabug references are replaced: `grep -r "com\.instabug" .`
- Verify version catalog syntax if using `libs.versions.toml`
- Verify `buildSrc` syntax and changes if in use

**Missing dependencies**
- Ensure Python 3.6+ is available: `python3 --version`

**Plugin configuration errors**
- Review plugin blocks in `build.gradle` files
- Ensure `luciq` plugin is applied instead of `instabug`
- Check for syntax errors in configuration blocks

**ProGuard/R8 issues**
- Verify ProGuard rules use `ai.luciq.*` instead of `com.instabug.*`
- Update any custom rules referencing Instabug classes

### Recovery

If migration fails or causes issues:

1. **Restore from backup**:
   ```bash
   rm -rf src/ build.gradle* settings.gradle*
   cp -r migration-backup/* .
   ```

2. **Clean and rebuild**:
   ```bash
   ./gradlew clean build
   ```

3. **Check specific issues**:
   - Review migration log output
   - Run with `--dry-run` to identify problematic files
   - Use `--source-only` for partial migration

### Getting Help

- **Check logs**: The script provides detailed output about what was changed
- **Verify requirements**: Ensure all system requirements are met
- **Test incrementally**: Use `--source-only` for staged migration
- **Manual fallback**: For complex projects, consider manual migration of specific files

---

**💡 Tip**: Always run `--dry-run` first to preview changes, especially on large or complex projects.
