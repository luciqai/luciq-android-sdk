#!/usr/bin/env python3
"""
Instabug to Luciq Migration Script

This script automatically migrates all package references from com.instabug.** to ai.luciq.**
in your Android project. It handles:
- Gradle files (version catalogs, dependencies, plugin configurations)
- Java/Kotlin files (package names, imports, class names, method names)
- Other files (AndroidManifest.xml, resources, ProGuard rules)

The migration follows the comprehensive migration guide and handles all scenarios including:
- Class name mappings (IBGNonFatalException -> LuciqNonFatalException)
- Method name mappings (isInstabugNotification -> isLuciqNotification)
- Plugin configurations (Instabug {} -> instabug {})
- Version catalogs and complex Gradle setups
- Resource files and manifest entries

Usage:
    python3 main-migrator.py [project_path]

If no project_path is provided, the script will run in the current directory.

Author: Instabug SDK Team
Version: 2.0.0
"""

import os
import re
import sys
import argparse
import shutil
from pathlib import Path
from typing import List, Dict, Set
import logging

# Import migration modules
from gradle_migrator import GradleMigrator
from code_migrator import CodeMigrator
from others_migrator import OthersMigrator

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

class OutputFileLogger:
    """Custom logger that writes to both console and file when needed"""
    def __init__(self, output_file_path: str = None):
        self.output_file_path = output_file_path
        self.output_content = []
        
    def log(self, message: str, to_console: bool = True):
        """Log message to console and/or capture for file"""
        if to_console:
            logger.info(message)
        if self.output_file_path:
            self.output_content.append(f"INFO: {message}")
    
    def log_step_header(self, message: str):
        """Log step headers to both console and file"""
        logger.info(message)
        if self.output_file_path:
            self.output_content.append(f"INFO: {message}")
    
    def write_to_file(self):
        """Write captured content to output file"""
        if self.output_file_path and self.output_content:
            try:
                with open(self.output_file_path, 'w', encoding='utf-8') as f:
                    f.write(f"# Instabug to Luciq Migration Dry Run Output\n")
                    f.write(f"# Generated on: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(f"# Project Path: {self.output_file_path.parent if hasattr(self.output_file_path, 'parent') else 'N/A'}\n")
                    f.write(f"# Mode: Comprehensive\n\n")
                    
                    for line in self.output_content:
                        f.write(f"{line}\n")
                
                logger.info(f"📄 Dry run output written to: {self.output_file_path}")
                return True
            except Exception as e:
                logger.error(f"Failed to write output file: {e}")
                return False
        return True

    @staticmethod
    def is_dry_run_output_file(file_path: Path) -> bool:
        """Check if a file is a dry-run output file by examining its header"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                first_line = f.readline().strip()
                return first_line.startswith("# Instabug to Luciq Migration Dry Run Output")
        except (UnicodeDecodeError, IOError):
            return False

class InstabugRebrandingScript:
    def __init__(self, project_path: str, dry_run: bool = False, source_only: bool = False, no_backup: bool = False, output_file: str = None):
        self.project_path = Path(project_path).resolve()
        self.backup_dir = self.project_path / "migration-backup"
        self.dry_run = dry_run
        self.source_only = source_only
        self.no_backup = no_backup
        self.output_file = output_file
        
        # Set up output file logger if specified
        if self.output_file and self.dry_run:
            output_file_path = self.project_path / self.output_file
            self.file_logger = OutputFileLogger(output_file_path)
        else:
            self.file_logger = OutputFileLogger()
        
        # Initialize migration modules
        if not source_only:
            self.gradle_migrator = GradleMigrator(self.project_path, dry_run, self.file_logger)
        else:
            self.gradle_migrator = None
        self.code_migrator = CodeMigrator(self.project_path, dry_run, self.file_logger)
        self.others_migrator = OthersMigrator(self.project_path, dry_run, self.file_logger)
        
        # Directories to skip for backup
        self.skip_dirs = {
            '.git', '.gradle', 'build', '.idea', 
            'gradle', 'migration-backup'
        }
        
        # Combined statistics
        self.stats = {
            'files_processed': 0,
            'files_modified': 0,
            'replacements_made': 0,
            'errors': 0
        }
    
    def _update_combined_stats(self):
        """Update combined statistics from all migrators"""
        code_stats = self.code_migrator.get_stats()
        others_stats = self.others_migrator.get_stats()
        
        if self.gradle_migrator:
            gradle_stats = self.gradle_migrator.get_stats()
            self.stats['files_processed'] = (
                gradle_stats['files_processed'] + 
                code_stats['files_processed'] + 
                others_stats['files_processed']
            )
            self.stats['files_modified'] = (
                gradle_stats['files_modified'] + 
                code_stats['files_modified'] + 
                others_stats['files_modified']
            )
            self.stats['replacements_made'] = (
                gradle_stats['replacements_made'] + 
                code_stats['replacements_made'] + 
                others_stats['replacements_made']
            )
            self.stats['errors'] = (
                gradle_stats['errors'] + 
                code_stats['errors'] + 
                others_stats['errors']
            )
        else:
            self.stats['files_processed'] = (
                code_stats['files_processed'] + 
                others_stats['files_processed']
            )
            self.stats['files_modified'] = (
                code_stats['files_modified'] + 
                others_stats['files_modified']
            )
            self.stats['replacements_made'] = (
                code_stats['replacements_made'] + 
                others_stats['replacements_made']
            )
            self.stats['errors'] = (
                code_stats['errors'] + 
                others_stats['errors']
            )
    
    def create_backup(self) -> bool:
        """Create a backup of the project before making changes"""
        try:
            if self.backup_dir.exists():
                logger.warning(f"Backup directory already exists: {self.backup_dir}")
                response = input("Do you want to overwrite the existing backup? (y/N): ")
                if response.lower() != 'y':
                    logger.info("Backup cancelled. Exiting.")
                    return False
                shutil.rmtree(self.backup_dir)
            
            logger.info(f"Creating backup at: {self.backup_dir}")
            logger.info("📋 Backing up original files before migration...")
            
            # Create backup directory
            self.backup_dir.mkdir(exist_ok=True)
            
            # Copy important files and directories
            important_patterns = [
                '*.java', '*.kt', '*.kts', '*.xml', '*.gradle', 
                '*.pro', '*.txt', '*.properties', '*.json'
            ]
            
            files_backed_up = 0
            for root, dirs, files in os.walk(self.project_path):
                # Skip backup directory and other unnecessary dirs
                dirs[:] = [d for d in dirs if d not in self.skip_dirs]
                
                # Extra safety: skip if we're inside the backup directory
                root_path = Path(root)
                if self.backup_dir in root_path.parents or root_path == self.backup_dir:
                    continue
                relative_path = root_path.relative_to(self.project_path)
                backup_path = self.backup_dir / relative_path
                
                for file in files:
                    file_path = root_path / file
                    if any(file_path.match(pattern) for pattern in important_patterns):
                        backup_file_path = backup_path / file
                        backup_file_path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(file_path, backup_file_path)
                        files_backed_up += 1
            
            logger.info(f"✅ Backup created successfully - {files_backed_up} files backed up")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create backup: {e}")
            return False
    
    def scan_and_process(self) -> bool:
        """Scan project and process all files using modular migrators"""
        self.file_logger.log_step_header("="*60)
        if self.source_only:
            self.file_logger.log_step_header("STARTING SOURCE-ONLY MIGRATION")
        else:
            self.file_logger.log_step_header("STARTING COMPREHENSIVE MIGRATION")
        self.file_logger.log_step_header("="*60)
        
        success = True
        step_num = 1
        
        # Step 1: Migrate Gradle files (version catalogs, dependencies, plugins) - Skip in source-only mode
        if not self.source_only:
            self.file_logger.log_step_header(f"\n🔧 STEP {step_num}: Migrating Gradle Files")
            self.file_logger.log_step_header("-" * 40)
            if not self.gradle_migrator.migrate_all_gradle_files():
                success = False
                logger.error("❌ Gradle migration failed")
            else:
                self.file_logger.log_step_header("✅ Gradle migration completed")
            step_num += 1
        
        # Step 2: Migrate Java/Kotlin code files
        self.file_logger.log_step_header(f"\n📝 STEP {step_num}: Migrating Java/Kotlin Files")
        self.file_logger.log_step_header("-" * 40)
        if not self.code_migrator.migrate_all_code_files():
            success = False
            logger.error("❌ Code migration failed")
        else:
            self.file_logger.log_step_header("✅ Code migration completed")
        step_num += 1
        
        # Step 3: Migrate other files (manifest, resources, proguard)
        self.file_logger.log_step_header(f"\n📄 STEP {step_num}: Migrating Other Files")
        self.file_logger.log_step_header("-" * 40)
        if not self.others_migrator.migrate_all_other_files():
            success = False
            logger.error("❌ Others migration failed")
        else:
            self.file_logger.log_step_header("✅ Others migration completed")
        
        # Update combined statistics
        self._update_combined_stats()
        
        self.file_logger.log_step_header("\n" + "="*60)
        if success:
            self.file_logger.log_step_header("🎉 ALL MIGRATION STEPS COMPLETED SUCCESSFULLY")
        else:
            logger.error("⚠️  MIGRATION COMPLETED WITH SOME ERRORS")
        self.file_logger.log_step_header("="*60)
        
        return success
    
    def print_summary(self):
        """Print comprehensive summary of all migration steps"""
        self.file_logger.log("\n" + "="*60)
        if self.dry_run:
            self.file_logger.log("COMPREHENSIVE DRY RUN SUMMARY")
        else:
            self.file_logger.log("COMPREHENSIVE MIGRATION SUMMARY")
        self.file_logger.log("="*60)
        
        # Overall statistics
        self.file_logger.log(f"Total files processed: {self.stats['files_processed']}")
        
        if self.dry_run:
            self.file_logger.log(f"Files that would be modified: {self.stats['files_modified']}")
            self.file_logger.log(f"Total replacements that would be made: {self.stats['replacements_made']}")
        else:
            self.file_logger.log(f"Files modified: {self.stats['files_modified']}")
            self.file_logger.log(f"Total replacements made: {self.stats['replacements_made']}")
        
        self.file_logger.log(f"Errors encountered: {self.stats['errors']}")
        
        # Detailed breakdown by migration type
        logger.info("\n" + "-"*40)
        logger.info("BREAKDOWN BY MIGRATION TYPE:")
        logger.info("-"*40)
        
        code_stats = self.code_migrator.get_stats()
        others_stats = self.others_migrator.get_stats()
        
        if self.gradle_migrator:
            gradle_stats = self.gradle_migrator.get_stats()
            logger.info("🔧 Gradle Files:")
            logger.info(f"   Processed: {gradle_stats['files_processed']}")
            logger.info(f"   Modified: {gradle_stats['files_modified']}")
            logger.info(f"   Replacements: {gradle_stats['replacements_made']}")
        
        logger.info("📝 Code Files:")
        logger.info(f"   Processed: {code_stats['files_processed']}")
        logger.info(f"   Modified: {code_stats['files_modified']}")
        logger.info(f"   Replacements: {code_stats['replacements_made']}")
        
        logger.info("📄 Other Files:")
        logger.info(f"   Processed: {others_stats['files_processed']}")
        logger.info(f"   Modified: {others_stats['files_modified']}")
        logger.info(f"   Replacements: {others_stats['replacements_made']}")
        
        # Migration mappings summary
        if not self.dry_run and self.stats['files_modified'] > 0:
            logger.info("\n" + "-"*40)
            logger.info("MIGRATION MAPPINGS APPLIED:")
            logger.info("-"*40)
            
            # Show key mappings
            logger.info("📦 Package Mappings:")
            for old_pkg, new_pkg in self.code_migrator.get_package_mappings().items():
                logger.info(f"   {old_pkg} → {new_pkg}")
            
            logger.info("🏷️  Class Mappings:")
            for old_class, new_class in self.code_migrator.get_class_mappings().items():
                logger.info(f"   {old_class} → {new_class}")
        
        # Final status and next steps
        logger.info("\n" + "="*60)
        if self.dry_run:
            if self.stats['files_modified'] > 0:
                logger.info("✅ DRY RUN COMPLETED - No actual changes were made")
                logger.info("📋 To apply these changes, run the script without --dry-run")
            else:
                logger.info("ℹ️  No Instabug references found in the project")
        else:
            if self.stats['files_modified'] > 0:
                logger.info("🎉 MIGRATION COMPLETED SUCCESSFULLY!")
                if not self.no_backup:
                    logger.info(f"💾 Original files backup created at: {self.backup_dir}")
                    logger.info("   ✅ Backup contains ORIGINAL files (before migration)")
                else:
                    logger.info("⚠️  No backup was created (--no-backup option used)")
                logger.info("\n📋 NEXT STEPS:")
                logger.info("1. Build your project: ./gradlew clean build")
                logger.info("2. Run your tests: ./gradlew test")
                logger.info("3. Test app functionality thoroughly")
                if not self.no_backup:
                    logger.info("4. If issues occur, restore from backup")
                else:
                    logger.info("4. If issues occur, restore from version control")
                logger.info("\n🔍 VERIFICATION COMMANDS:")
                if not self.no_backup:
                    logger.info('   grep -r "com\\.instabug" . --exclude-dir=migration-backup')
                else:
                    logger.info('   grep -r "com\\.instabug" .')
                logger.info("   (Should return no results)")
            else:
                logger.info("ℹ️  No Instabug references found in the project")
        
        logger.info("="*60)
    
    def run(self) -> bool:
        """Run the complete rebranding process"""
        if self.dry_run:
            if self.source_only:
                logger.info("Starting Instabug to Luciq source-only rebranding analysis (DRY RUN)...")
            else:
                logger.info("Starting Instabug to Luciq rebranding analysis (DRY RUN)...")
        else:
            if self.source_only:
                logger.info("Starting Instabug to Luciq source-only rebranding process...")
            else:
                logger.info("Starting Instabug to Luciq rebranding process...")
        
        # Validate project path
        if not self.project_path.exists():
            logger.error(f"Project path does not exist: {self.project_path}")
            return False
        
        # Create backup (skip in dry-run mode or if no-backup is specified)
        if not self.dry_run and not self.no_backup:
            if not self.create_backup():
                return False
        
        # Process files
        success = self.scan_and_process()
        
        # Print summary
        self.print_summary()
        
        # Write output file if specified and in dry-run mode
        if self.dry_run and self.output_file:
            self.file_logger.write_to_file()
        
        return success

def main():
    parser = argparse.ArgumentParser(
        description="Rebrand Instabug SDK references from com.instabug.* to ai.luciq.*"
    )
    parser.add_argument(
        'project_path', 
        nargs='?', 
        default='.', 
        help='Path to the Android project (default: current directory)'
    )
    parser.add_argument(
        '--dry-run', 
        action='store_true', 
        help='Show what would be changed without making actual changes'
    )
    parser.add_argument(
        '--no-backup', 
        action='store_true', 
        help='Skip creating backup (not recommended)'
    )
    parser.add_argument(
        '--source-only', 
        action='store_true', 
        help='Migrate only Java/Kotlin files, Manifest & resources (skip Gradle)'
    )
    parser.add_argument(
        '--output-file', 
        type=str, 
        help='Output file to write dry-run changes (only works with --dry-run)'
    )
    
    args = parser.parse_args()
    
    # Validate output-file option
    if args.output_file and not args.dry_run:
        logger.error("--output-file can only be used with --dry-run")
        return False
    
    if args.dry_run:
        if args.source_only:
            logger.info("DRY RUN MODE (SOURCE-ONLY) - No changes will be made")
        else:
            logger.info("DRY RUN MODE - No changes will be made")
        if args.output_file:
            logger.info(f"Output will be written to: {args.output_file}")
    elif args.source_only:
        logger.info("SOURCE-ONLY MODE - Skipping Gradle migration")
    
    try:
        script = InstabugRebrandingScript(
            args.project_path, 
            dry_run=args.dry_run, 
            source_only=args.source_only, 
            no_backup=args.no_backup,
            output_file=args.output_file
        )
        success = script.run()
        return success
            
    except KeyboardInterrupt:
        logger.info("\nOperation cancelled by user")
        return False
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
